#include <QtGui>
#include "stdlib.h"
#include "mainwindow.h"
#include <string>
#include <fstream>
#include <iostream>
#include <sstream>
#include <algorithm>
#include <QtSvg>
#include <QSvgGenerator>

#include "names.h"
#include "polygons.h"
#include "edit_distance.h"

#include <vector>

using namespace std;
MainWindow::MainWindow()
{


 QString prevname=("");
 for(int i=0;i<629;i++)
 { QString aname = QString(QString::fromUtf8(oblasti_char[i]));
  oblasti.push_back(aname); if(aname != prevname)oblasti_un.push_back(aname);
  prevname=aname;

 aname = QString::fromUtf8(rayony_char[i]);
 rayony.push_back(aname);

 aname = QString::fromUtf8(punkty_char[i]);
 punkty.push_back(aname);

 //c out << oblasti[i].toStdString()<<" "<<rayony[i].toStdString()<<" "<<punkty[i].toStdString() <<"\n";
 transl2[itransl[i]-1]=i;
 }
 sort(oblasti_un.begin(),oblasti_un.end());
 oblasti_un.erase(unique(oblasti_un.begin(),oblasti_un.end()),oblasti_un.end());


 QComboBox * obl_box = new QComboBox();

      cout <<"Області\n";
 for(int i=0;i<oblasti_un.size();i++)
 {obl_box->addItem(oblasti_un[i]);                       cout << oblasti_un[i].toStdString()<<"\n";
  QStringList alist;
  imena_po_oblastyah.push_back(alist);
  vector <int> ivec;
  ints_po_oblastyah.push_back(ivec);
  //QVector <double> dvec;
  //dubs_po_oblastyah.push_back(dvec);
  vector <PolygonBrusher * > pbvec;
  brushers.push_back(pbvec);
 }

 
 
  for(int i=0;i<629;i++)
 { QString aname = (punkty[i].isEmpty())?rayony[i]:punkty[i];

   for(int j=0;j<oblasti_un.size();j++)
  {if(oblasti[i]==oblasti_un[j])
    {imena_po_oblastyah[j].push_back(aname);
     ints_po_oblastyah[j].push_back(i);
     //dubs_po_oblastyah[j].push_back(-1);
     QVector <QGraphicsPolygonItem *> pvec;
     PolygonBrusher * pb= new PolygonBrusher(pvec);
     brushers[j].push_back(pb);
     break;
    }
  }
 //cout << oblasti[i].toStdString()<<" "<<rayony[i].toStdString()<<" "<<punkty[i].toStdString() <<"\n";
 }

 // QObject::
 connect(obl_box, SIGNAL(currentIndexChanged(int )), this, SLOT(oblast_changed(int )));
     imageAngleSizeXcoeff = 32.0;
     imageAngleSizeYcoeff = 0.75;
     centerFrequencyd = 32.0;
     kd = 0.4;
     pyramidThresholdd = 0.65;
     pyramidDmaxd = 0.15;
     pyramidNumIterationsd = 3;
     mergeDMaxd = 0.15;
     mergeThresholdd = 1.0;
     filterMind = 15;
     filterMaxd = 8000;
     scale0=1.0;
     scale1=1.0;
     ellipsesXs=NULL;
     ellipsesYs=NULL;
     ellipsesAreas=NULL;
     lambdaMax = 1.0;

    imagePixelSizeX = 640;
    imagePixelSizeY = 480;
    imageAngleSizeX = imagePixelSizeX / imageAngleSizeXcoeff;//imagePixelSizeX / 64.0 * 2.0; // because 64 pixels equal 2 degree
    imageAngleSizeY = imageAngleSizeX * imageAngleSizeYcoeff;//imageAngleSizeX * 0.75; // ratio 4:3
    centerFrequency = centerFrequencyd;
    k = kd;
    pyramidThreshold = pyramidThresholdd;
    pyramidDmax = pyramidDmaxd;
    pyramidNumIterations = pyramidNumIterationsd;
    mergeDMax = mergeDMaxd;
    mergeThreshold = mergeThresholdd;
    filterMin = filterMind;
    filterMax = filterMaxd;
    QWidget *w = new QWidget;
    setCentralWidget(w);

    QWidget *topFiller = new QWidget;
    topFiller->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);


    QWidget *bottomFiller = new QWidget;
    bottomFiller->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);

 QPushButton * runbutton = new QPushButton(tr("(Don't!)Run"));
 QObject::connect(runbutton, SIGNAL(pressed()), this, SLOT(runPressed()));

 QPushButton * dfltbutton = new QPushButton(tr("Clear"));
 QObject::connect(dfltbutton, SIGNAL(pressed()), this, SLOT(putDefaults()));

 QLabel * ipsx_lbl = new QLabel(QString("poly from"));
 ipsx_spb = new QSpinBox();
 ipsx_spb->setMaximum(629);
 ipsx_spb->setMinimum(0);
 ipsx_spb->setValue(imagePixelSizeX);
 QObject::connect(ipsx_spb, SIGNAL(valueChanged(int )), this, SLOT(ipsx_changed(int )));


 QLabel * ipsy_lbl = new QLabel(QString("poly to"));
 ipsy_spb = new QSpinBox();
 ipsy_spb->setMaximum(629);
 ipsy_spb->setMinimum(0);
 ipsy_spb->setValue(imagePixelSizeY);
 QObject::connect(ipsy_spb, SIGNAL(valueChanged(int )), this, SLOT(ipsy_changed(int )));

 QLabel * iasx_lbl = new QLabel(QString("grid size X"));
 iasx_spb = new QDoubleSpinBox();
 iasx_spb->setDecimals(3);
 iasx_spb->setMaximum(10000.0);
 iasx_spb->setValue(imageAngleSizeX);
 iasx_spb->setSingleStep(2.0);
 QObject::connect(iasx_spb, SIGNAL(valueChanged(double )), this, SLOT(iasx_changed(double )));

 QLabel * iasy_lbl = new QLabel(QString("grid size Y"));
 iasy_spb = new QDoubleSpinBox();
 iasy_spb->setDecimals(3);
 iasy_spb->setMaximum(10000.0);
 iasy_spb->setValue(imageAngleSizeY);
 iasy_spb->setSingleStep(2.0);
 QObject::connect(iasy_spb, SIGNAL(valueChanged(double )), this, SLOT(iasy_changed(double )));

 


 QVBoxLayout *controls = new QVBoxLayout;


 controls->addWidget(obl_box);
 sa = new QScrollArea;
 QGridLayout * gl = new QGridLayout();

 gl->setMargin(0);
 gl->setContentsMargins(0,0,0,0);
 gl->setSpacing(0);
 fr= new  QFrame();
 fr->resize(50,50);
 //fr->setLayout(gl);
 sa->setSizePolicy(QSizePolicy::Ignored, QSizePolicy:: Preferred);
 sa->setWidget(fr);
// sa->setMinimumSize(50,100);
 //sa->resize(50,100);
 sa->resize( QSize( 50, 50 ) );
 //gl->addWidget(new QLabel("alabel"),0,0);
 controls->addWidget(sa);
 te = new QTextEdit();  te->setSizePolicy(QSizePolicy::Ignored, QSizePolicy:: Preferred);
 QObject::connect(te,SIGNAL(textChanged()),this,SLOT(parseEdit()));
 controls->addWidget(te);
 QHBoxLayout *controlsRow1 = new QHBoxLayout;
 controlsRow1->addWidget(dfltbutton);
 controlsRow1->addWidget(runbutton);
 controls->addLayout(controlsRow1);

 QHBoxLayout *controlsRow2 = new QHBoxLayout;
 controlsRow2->addWidget(ipsx_lbl);
 controlsRow2->addWidget(ipsx_spb);
 controls->addLayout(controlsRow2);

 QHBoxLayout *controlsRow3 = new QHBoxLayout;
 controlsRow3->addWidget(ipsy_lbl);
 controlsRow3->addWidget(ipsy_spb);
 controls->addLayout(controlsRow3);

// controls->addWidget(ipsx_spb);
// controls->addWidget(ipsy_lbl);
 //controls->addWidget(ipsy_spb);

 QHBoxLayout *controlsRow4 = new QHBoxLayout;
 controlsRow4->addWidget(iasx_lbl);
 controlsRow4->addWidget(iasx_spb);
 controls->addLayout(controlsRow4);

 //controls->addWidget(iasx_lbl);
// controls->addWidget(iasx_spb);
 QHBoxLayout *controlsRow5 = new QHBoxLayout;
 controlsRow5->addWidget(iasy_lbl);
 controlsRow5->addWidget(iasy_spb);
 controls->addLayout(controlsRow5);



    QHBoxLayout *hbox = new QHBoxLayout;
    hbox->setMargin(0);
    hbox->addLayout(controls);
    //hbox->addWidget(uTEdit);
    graphicsView = new QGraphicsView;
    graphicsScene = new QGraphicsScene;
    graphicsView0 = new QGraphicsView;
    graphicsScene0 = new QGraphicsScene;
    graphicsView0->setScene(graphicsScene0);
    graphicsView->setScene(graphicsScene);
    //graphicsView0->scale(0.5,0.5);
    //graphicsView0->setSizePolicy ( QSizePolicy::Preferred, QSizePolicy::Preferred );
    //graphicsView0->setHorizontalStretch();
    //graphicsView0->resize(graphicsScene0->itemsBoundingRect().size().width(),graphicsScene0->itemsBoundingRect().size().height());
    //graphicsView->setScene(graphicsScene);
    //QTextEdit *textedit = new QTextEdit;
    graphicsView0->setRenderHint(QPainter::Antialiasing, true);
    graphicsView0->setDragMode(QGraphicsView::RubberBandDrag);
    graphicsView->setRenderHint(QPainter::Antialiasing, true);
    graphicsView->setDragMode(QGraphicsView::RubberBandDrag);

    vSplitter = new QSplitter;
    //QMainWindow * mw = new QMainWindow;
    //mw->setCentralWidget(graphicsView0);
    //l1 = new QHBoxLayout();
    //l1->addWidget(graphicsView0);
    vSplitter->addWidget(graphicsView0);
    //fr = new QFrame();
    //fr->setLayout(l1);
    //vSplitter->addWidget(fr);
    vSplitter->addWidget(graphicsView);
    hbox->addWidget(vSplitter);
    //hbox->addWidget(graphicsView0);
    //hbox->addWidget(graphicsView);
    connect(vSplitter,SIGNAL(splitterMoved(int,int)),this, SLOT(vsplitterMoved(int,int)));
    //c out << "fh= "<< vSplitter->geometry().height()<<"\n";
    w->setLayout(hbox);

    createActions();
    createMenus();

    //statusBar()->showMessage(tr("A context menu is available by right-clicking"));

    setWindowTitle(tr("Easy Map"));
    setMinimumSize(160, 160);
    resize(1280, 700);
//scenes resize
  int h = vSplitter->geometry().height();
  QList<int> szs = vSplitter->sizes();
  double sc1l= (szs[0]-5)/((double)imagePixelSizeX);
  double sc1r= (szs[1]-5)/((double)imagePixelSizeX);
  double sc2= h/((double)imagePixelSizeY);
  double scl = sc1l; if (sc2<sc1l) scl= sc2;
  double scr = sc1r; if (sc2<sc1r) scr= sc2;
  //c out << "scr=" <<scr<<" ";
  if(szs[0]>10)
  {
   graphicsView0->scale(scl/scale0,scl/scale0);
   graphicsView0->update();  
   scale0=scl;
  }
  if(szs[1]>10)
  {
   graphicsView->scale(scr/scale1,scr/scale1);
   graphicsView->update();
   //c out << "res "<< scr/scale1 <<" ";
   scale1=scr;
  }
//end of scenes resize
    QStringList our_args = QCoreApplication::arguments();
 autofile = NULL;
 file_name="";
 oocva_dlg=NULL;
 runbutton->setFocus();
 if (our_args.size()>1){}


 for(int i=0;i<806;i++)
 { QString apolyg = QString(polygons[i]);
   apolyg.replace(',',' ');
  double value;
  vector <double> dvalues;
  istringstream iss(apolyg.toStdString());
  while (iss >> value)
  {
   dvalues.push_back(value);
  }
 QPolygonF polyg;
 for(int i=0;i<dvalues.size()/2;i++) polyg <<QPointF(dvalues[i*2]*40,500-dvalues[i*2+1]*40);
 graphicsScene->addPolygon(polyg);
 polygs.push_back(polyg);
// c out << oblasti[i].toStdString()<<" "<<rayony[i].toStdString()<<" "<<punkty[i].toStdString() <<"\n";
 }

//read polygons correctly
 QFile file(QString("polygons2.txt"));
 QTextStream in(&file); 
   //c out << "to read file\n";fflush(stdout);
  if (!file.open(QFile::ReadOnly)) {
        QString msg = tr("Failed to open %1\n%2")
                        .arg(QString("/home/oleg/prog/juornal/qt/polygons2.txt"))
                        .arg(file.errorString());
        QMessageBox::warning(this, tr("Error"), msg);

 }
  QString line1=in.readLine();  // line1=in.readLine(); line1=in.readLine(); line1=in.readLine(); line1=in.readLine();
  //c out << line1.toStdString()<<"\n";fflush(stdout);
 int curPol=0;
  while (!in.atEnd())
 { QString line = in.readLine();
 if(line.startsWith("$polygons["))
  { //c out <<line.toStdString();
   QString strnum="";
   for(int j=0;j<line.length();j++)
        if(line.at(j).isNumber())strnum+=line.at(j);
   curPol=strnum.toInt()-1;
   //c out << strnum.toInt()<<"\n";
   while(polygs2.size()<(curPol+1)) {QVector <QPolygonF> polVec; polygs2.push_back(polVec);}
  }
 if(line==QString("Slot \"coords\":"))
  {QPolygonF apol;
     line=in.readLine();
      while (! line.isEmpty())
     {line = in.readLine();
      while(line.startsWith (QString(" ") ))line.remove(0,1);
     // else  if(line.startsWith (QString("  ") ))line.remove(0,2);
      //else  if(line.startsWith (QString("   ") ))line.remove(0,3);
      QRegExp rx("[ ]");
      QStringList lineParts = line.split(rx);
      if((! line.isEmpty()))
        {//c out << lineParts[0].toStdString()<<" " <<lineParts[1].toDouble()<<" "<<lineParts[2].toDouble()<<"\n";
         apol << QPointF(lineParts[1].toDouble()*40,500- lineParts[2].toDouble()*40);
        }

 //fflush(stdout);
     //if(line.startsWith("$polygons["))
     }
  polygs2[curPol].push_back(apol);
  }
   
  }
// c out<< polygs2.size() << " "<<polygs2[628].size()<<"\n";// for(int i=0;i<(int)polygs2[628][1].size();i++) // c out <<polygs2[628][1][i].x() <<" "<<polygs2[628][1][i].y() <<" ";
 fflush(stdout);
//end of read polygons correctly

 cout << "edit distance for 'mokANDER' and  'SLANDER' is " << edit_distance("mokANDER", "SLANDER")<<"\n";
 oblast_changed(0 );
}

void MainWindow::oblast_changed(int obl)
{cout << obl<<"\n";
 cur_obl= obl;
 cur_spbs.clear();
 //graphicsScene->clear();
 sa->setMinimumHeight(100);
 //cout <<"nr=" << obl_gl->rowCount()<<"??";
 //cout <<"at00=="<< obl_gl->itemAtPosition(0,0)<<"!!";
 //sb->removeWidget(fr);
 //delete fr;
 fr=new QFrame;
 // obl_gl->update();
 //sb->update();
/* for(int i=obl_gl->rowCount()-1;i>=0;i--)
 {QLabel*lbl= (QLabel *) obl_gl->itemAtPosition(i,0);
  if(lbl != 0){obl_gl->removeWidget(lbl);
  lbl->~QLabel();}
  cout << "rc"<<i<<"&";
 }
 obl_gl->~QGridLayout();
 obl_gl = new QGridLayout();
*/
 //obl_gl->addWidget(new QLabel("2label"),0,0); 
 QGridLayout * gl= new QGridLayout();
 for(int i=0;i<imena_po_oblastyah[obl].size();i++){
  cout << imena_po_oblastyah[obl][i].toStdString()<<"\n";
  QDoubleSpinBox * spb= new QDoubleSpinBox();
  cur_spbs.push_back(spb);
  QLabel * lbl = new QLabel(imena_po_oblastyah[obl][i]);
  gl->addWidget(spb,i,0); gl->addWidget(lbl,i,1);
  spb->setMinimum(-1);  spb->setValue(  brushers[obl][i]->getDVal());
 /* for(int ip=0;ip<(int)polygs2[itransl[ints_po_oblastyah[obl][i]]-2].size();ip++)
  {graphicsScene->addPolygon(polygs2[itransl[ints_po_oblastyah[obl][i]]-2][ip],QPen(QColor(255,0,0,255)));
  }*/

 QGraphicsPolygonItem * agpi;
 QVector <QGraphicsPolygonItem *> gpis;
  for(int ip=0;ip<(int)polygs2[ints_po_oblastyah[obl][i]].size();ip++)
  {QGraphicsPolygonItem * gpi =graphicsScene->addPolygon(polygs2[ints_po_oblastyah[obl][i]][ip],QPen(QColor(255,0,0,255)));
     gpi->setToolTip(imena_po_oblastyah[obl][i]);
     //gpi->setBrush(QColor(0,255,0,255));
     agpi=gpi;gpis.push_back(gpi);
     
  }
  brushers[obl][i]->changeItems(gpis);
  connect(spb,SIGNAL(valueChanged(double)),brushers[obl][i],SLOT(rebrush(double)));

  //graphicsScene->addPolygon(polygs[ints_po_oblastyah[obl][i]],QPen(QColor(255,0,0,255)));
 }
 fflush(stdout);
  fr->setLayout (gl);
 sa->setWidget(fr);

}

////&*&*&*&*&****&*&*&&&*&**&**&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&

void MainWindow::parseEdit()
{cout<<"parsing Edit\n"; 
 QRegExp rx("[:;,]");
 QStringList splittedText = QString(te->toPlainText().toUtf8()).split(rx);
 QStringList names;
 QVector <double> vals;
 int neededNum=0;// 0- text, 1- number
 for(int i=0;i<splittedText.size();i++)
 {
  if(! neededNum)
  {
  bool yes;
  double d;
  d = splittedText[i].toDouble(&yes); // ok == true, d == 12.3456 
  if(! yes)
   {while (splittedText[i].startsWith(" "))splittedText[i].remove(0,1);
    if(splittedText[i].size()>0){names.push_back(splittedText[i]); neededNum=1;}
   }
   else if(vals.size()>0)vals[vals.size()-1]=d;
  }
  else
  {
   bool yes;
   double d;
   d = splittedText[i].toDouble(&yes); // ok == true, d == 12.3456 
   if( yes)
   {vals.push_back(d); neededNum=0;
   }
   else
   {while (splittedText[i].startsWith(" "))splittedText[i].remove(0,1);
    if((splittedText[i].size()>0)&(names.size()>0)){names[names.size()-1]=splittedText[i];}
   }
  }
 }

 int n=(vals.size()<names.size())?vals.size():names.size();
 for(int i=0;i<n;i++) cout <<names[i].toStdString()<<" "<<vals[i]<<"\n";
 fflush(stdout);
 //read of couples done, starting search 
 vector <int> matched_obls; 
 vector <int> matched_input;
 for (int i =0;i<(int)names.size();i++) matched_input.push_back(0);
 for (int i =0;i<(int)imena_po_oblastyah[cur_obl].size();i++) matched_obls.push_back(0);
 
 for (int i =0;i<(int)imena_po_oblastyah[cur_obl].size();i++)
  for (int j =0;j<(int)names.size();j++)
  {if(imena_po_oblastyah[cur_obl][i].toUtf8()==names[j])
   {cout << "po_obl:"<<imena_po_oblastyah[cur_obl][i].toStdString()<<"\n";
    cur_spbs[i]->setValue(vals[j]);
    matched_obls[i]=1;
    matched_input[j]=1;
   }
  }
 
}

void MainWindow::closew()
{                          QCoreApplication::quit();
}

/*void MainWindow::contextMenuEvent(QContextMenuEvent *event)
{
    QMenu menu(this);
    menu.addAction(cutAct);
    menu.addAction(copyAct);
    menu.addAction(pasteAct);
    menu.exec(event->globalPos());
}*/

void MainWindow::chooseFile()
{
  QString fileName;
  if (autofile ==NULL)
    {//if(ftype==1)
        fileName  = QFileDialog::getOpenFileName(this, tr("Choose an image"),"./",tr(" (*.* *.* *)"));
     //else fileName  = QFileDialog::getOpenFileName(ourWidget, tr("Load list of pairs of edges"),"./",tr("(*.* *)"));
    if (fileName.isEmpty())
    return;}
  else fileName = *autofile;
    QFile file(fileName);
    //if (!file.open(QFile::ReadOnly)) 
   QFileInfo *afi= new QFileInfo(fileName);
    if(!((afi->exists())&(afi->isFile())))

    {
        QString msg = tr("Failed to choose %1\n%2")
                        .arg(fileName)
                        .arg(file.errorString());
        QMessageBox::warning(this, tr("Error: "), msg);
        return;
    }
//  file_name=  QFileInfo::QFileInfo(fileName).baseName();.

    file_name= fileName;
    setWindowTitle(tr("QIIP: %1").arg(fileName));
    //QPixmap::QPixmap ( const QString & fileName, const char * format = 0, Qt::ImageConversionFlags flags = Qt::AutoColor )
    QPixmap pm = QPixmap(fileName);
    if((pm.width()>0)&(pm.height()>0))
    {imagePixelSizeXd=pm.width();
     imagePixelSizeYd=pm.height();
     imagePixelSizeX=imagePixelSizeXd;
     imagePixelSizeY=imagePixelSizeYd;
     imageAngleSizeX = imagePixelSizeX / imageAngleSizeXcoeff;
     imageAngleSizeY = imageAngleSizeX*((double)imagePixelSizeY/(double)imagePixelSizeX);//imageAngleSizeX * imageAngleSizeYcoeff;
     ipsx_spb->setValue(imagePixelSizeX);
     ipsy_spb->setValue(imagePixelSizeY);
     iasx_spb->setValue(imageAngleSizeX);
     iasy_spb->setValue(imageAngleSizeY);
     graphicsScene0->clear();
     graphicsScene0->addPixmap(pm);
    // graphicsScene0->render(pm);
     //c out << "fh= "<< vSplitter->geometry().height()<<"\n";
    }
 //r unIIP(&file);
 //return ;
    //infoLabel->setText(tr("Invoked <b>File|New</b>"));
}





//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
int MainWindow::open()
{
    //infoLabel->setText(tr("Invoked <b>File|Open</b>"));

 QString fileName;
  if (autofile ==NULL)
    {//if(ftype==1)
        fileName  = QFileDialog::getOpenFileName(this, tr("Load an image"),"./",tr(" (*.* *.* *)"));
     //else fileName  = QFileDialog::getOpenFileName(ourWidget, tr("Load list of pairs of edges"),"./",tr("(*.* *)"));
    if (fileName.isEmpty())
    return 0;}
  else fileName = *autofile;
    //QFile file(fileName);
    //if (!file.open(QFile::ReadOnly)) 
    QFileInfo *afi= new QFileInfo(fileName);
    if(!((afi->exists())&(afi->isFile())))
   {
        QString msg = tr("File does not exist %1\n")
                        .arg(fileName);
                        //.arg(file.errorString());
        QMessageBox::warning(this, tr("Error: "), msg);
        return 0;
    }
//  file_name=  QFileInfo::QFileInfo(fileName).baseName();.

    file_name= fileName;
    setWindowTitle(tr("QIIP: %1").arg(fileName));
    QPixmap pm = QPixmap(fileName);
    if((pm.width()>0)&(pm.height()>0))
    {imagePixelSizeXd=pm.width();
     imagePixelSizeYd=pm.height();
     imagePixelSizeX=imagePixelSizeXd;
     imagePixelSizeY=imagePixelSizeYd;
     imageAngleSizeX = imagePixelSizeX / imageAngleSizeXcoeff;
     imageAngleSizeY = imageAngleSizeX*((double)imagePixelSizeY/(double)imagePixelSizeX);//imageAngleSizeX * imageAngleSizeYcoeff;
     ipsx_spb->setValue(imagePixelSizeX);
     ipsy_spb->setValue(imagePixelSizeY);
     iasx_spb->setValue(imageAngleSizeX);
     iasy_spb->setValue(imageAngleSizeY);
     graphicsScene0->clear();
     graphicsScene0->addPixmap(pm);
    }
 //graphicsScene->clear();
 //graphicsView->setBackgroundBrush(QBrush (QColor ( 250, 0, 0,255 )  ));
 //graphicsScene->setSceneRect ( 0 , 0, (qreal) imagePixelSizeX, (qreal) imagePixelSizeY );
 //graphicsScene->addSimpleText(QString("C omputing... Please wait."));
 //graphicsView->update();
 runIIP();
 return 0;
}

void MainWindow::save()
{
    //infoLabel->setText(tr("Invoked <b>File|Save</b>"));
}

void MainWindow::print()
{
    //infoLabel->setText(tr("Invoked <b>File|Print</b>"));
}



void MainWindow::about()
{
    //infoLabel->setText(tr("Invoked <b>Help|About</b>"));
    QMessageBox::about(this, tr("About Easy Map"),
            QString::fromUtf8("The <b>Easy Map Україна</b> Qt interface (kind o' prototype). <BR>\n"
                "© Oleg Strogan <BR>\n olegstrogan@gmail.com"));
}

void MainWindow::aboutQt()
{
    //infoLabel->setText(tr("Invoked <b>Help|About Qt</b>"));
}

void MainWindow::createActions()
{
    chooseAct = new QAction(tr("Don't &choose a \"BMP\" file!"), this);
    chooseAct->setShortcut(tr("Ctrl+N"));
    chooseAct->setStatusTip(tr("Don't Choose a file"));
    connect(chooseAct, SIGNAL(triggered()), this, SLOT(chooseFile()));

    openAct = new QAction(tr("Don't &Open..."), this);
    openAct->setShortcut(tr("Ctrl+O"));
    openAct->setStatusTip(tr("Don't Open an existing file"));
    connect(openAct, SIGNAL(triggered()), this, SLOT(open()));



    //testAct = new QAction(QString("&Open..."), this);
    //testAct->setShortcut(tr("Ctrl+T"));
    //openAct->setStatusTip(tr("Open an existing file"));
    pathAct = new QAction(tr("scanpa&th"), this);
    pathAct->setShortcut(tr("Ctrl+T"));
    pathAct->setStatusTip(tr("showh scan path "));
    pathAct->setEnabled(false);
    connect(pathAct, SIGNAL(triggered()), this, SLOT(scanPath()));

    pathSaveAct = new QAction(tr("save s&canpath"), this);
    pathSaveAct->setStatusTip(tr("save scan path  into file"));
    pathSaveAct->setEnabled(false);
    connect(pathSaveAct, SIGNAL(triggered()), this, SLOT(saveScanPath()));

    saveImageFilesAct = new QAction(tr("save map into file"), this);
    saveImageFilesAct->setStatusTip(tr("save map into png/svg format file"));
    //saveImageFiles0Act->setEnabled(false);
    connect(saveImageFilesAct, SIGNAL(triggered()), this, SLOT(imageDialog()));


    saveImageFiles0Act = new QAction(tr("save image"), this);
    saveImageFiles0Act->setStatusTip(tr("save original image (with changes) into file"));
    saveImageFiles0Act->setEnabled(false);
    connect(saveImageFiles0Act, SIGNAL(triggered()), this, SLOT(saveImageFiles0()));

    saveImageFiles1Act = new QAction(tr("save protypes image"), this);
    saveImageFiles1Act->setStatusTip(tr("save prototypes image into file"));
    saveImageFiles1Act->setEnabled(false);
    connect(saveImageFiles1Act, SIGNAL(triggered()), this, SLOT(saveImageFiles1()));

    drawAttentionMapAct = new QAction(tr("draw &attention map"), this);
    drawAttentionMapAct->setStatusTip(tr("draw attention areas by the scan path record"));
    drawAttentionMapAct->setEnabled(false);
    connect(drawAttentionMapAct, SIGNAL(triggered()), this, SLOT(drawAttentionMap()));

    oocvaAct = new QAction(tr("oocva"), this);
    oocvaAct->setStatusTip(tr("run oocva"));
    //oocvaAct->setEnabled(false);
    connect(oocvaAct, SIGNAL(triggered()), this, SLOT(run_oocva()));

    oocvaConfAct = new QAction(tr("oocva configurable"), this);
    oocvaConfAct->setStatusTip(tr("run oocva with config dialog"));
    //oocvaAct->setEnabled(false);
    connect(oocvaConfAct, SIGNAL(triggered()), this, SLOT(run_oocva_dlg()));

    simAct = new QAction(tr("compare attention paths"), this);
    simAct->setStatusTip(tr("enter to scanpaths of the image to compare"));
    //oocvaAct->setEnabled(false);
    connect(simAct, SIGNAL(triggered()), this, SLOT(call_pathSim()));




    saveAct = new QAction(tr("&Save"), this);
    saveAct->setShortcut(tr("Ctrl+S"));
    saveAct->setStatusTip(tr("Save the document to disk"));
    saveAct->setEnabled(false);
    connect(saveAct, SIGNAL(triggered()), this, SLOT(save()));

    printAct = new QAction(tr("&Print..."), this);
    printAct->setShortcut(tr("Ctrl+P"));
    printAct->setStatusTip(tr("Print the document"));
    printAct->setEnabled(false);
    connect(printAct, SIGNAL(triggered()), this, SLOT(print()));

    exitAct = new QAction(tr("E&xit (yes, exits when pressed)"), this);
    exitAct->setShortcut(tr("Ctrl+Q"));
    exitAct->setStatusTip(tr("Exit the application"));
    connect(exitAct, SIGNAL(triggered()), this, SLOT(close()));


    aboutAct = new QAction(tr("&About"), this);
    aboutAct->setStatusTip(tr("Show the application's About box"));
    connect(aboutAct, SIGNAL(triggered()), this, SLOT(about()));

    aboutQtAct = new QAction(tr("About &Qt"), this);
    aboutQtAct->setStatusTip(tr("Show the Qt library's About box"));
    connect(aboutQtAct, SIGNAL(triggered()), qApp, SLOT(aboutQt()));
    connect(aboutQtAct, SIGNAL(triggered()), this, SLOT(aboutQt()));
}

void MainWindow::createMenus()
{
    fileMenu = menuBar()->addMenu(tr("&File"));
    fileMenu->addAction(chooseAct);
    
    fileMenu->addAction(openAct);
    //fileMenu->addAction(testAct);
    fileMenu->addAction(saveAct);
    fileMenu->addAction(printAct);
    fileMenu->addSeparator();
    fileMenu->addAction(exitAct);

    imageMenu = menuBar()->addMenu(tr("&Image"));
    imageMenu->addAction(saveImageFilesAct);
    imageMenu->addAction(pathAct);
    imageMenu->addAction(drawAttentionMapAct);
    imageMenu->addAction(pathSaveAct);
    imageMenu->addAction(saveImageFiles0Act);
    imageMenu->addAction(saveImageFiles1Act);
    //imageMenu->addAction(oocvaAct);
    QMenu * oocvaMenu = new QMenu(tr("oocva"));
    oocvaMenu->addAction(oocvaAct);
    oocvaMenu->addAction(oocvaConfAct);
    oocvaMenu->addAction(simAct);
    // imageMenu->addMenu(oocvaMenu);

    helpMenu = menuBar()->addMenu(tr("&Help"));
    helpMenu->addAction(aboutAct);
    helpMenu->addAction(aboutQtAct);
}

void MainWindow::runIIP()
{	//graphicsScene->clear();
	graphicsView->setBackgroundBrush(QBrush (QColor ( 250, 0, 0,255 )  ));
	graphicsScene->setSceneRect ( 0 , 0, (qreal) imagePixelSizeX, (qreal) imagePixelSizeY );
	graphicsScene->addSimpleText(QString("Computing... Please wait."));
	graphicsView->update();
	ThreadRunner * trunner = new ThreadRunner(protodata,this);
	connect(trunner, SIGNAL(computed(uchar*, int,int,int)),this,SLOT(drawEllipses(uchar *,int,int,int)));
	connect(trunner, SIGNAL(sendECoords(int,double *,double *,double *)),this,SLOT(setECoords(int,double *,double *,double *)));
	trunner->start();
	return;
}

void MainWindow::drawEllipses(uchar * udata, int xsz,int ysz,int rp)
{
	QImage img= QImage(xsz,ysz,QImage::Format_RGB888);
	img.fill(Qt::transparent);
	for ( int j = 0; j <ysz; j++ )
	{
	for ( int i = 0; i <xsz; i++ )
		{
		QRgb pixel;
		uint yshift = j*rp+(i*3);
		//pixel = qRgb(udata[j*rowpadded+2+(i*3)],udata[j*rowpadded+1+(i*3)],udata[j*rowpadded+0+(i*3)]);		//c out <<udata[j*xsz*3+(i*3)] <<" "<<udata[j*xsz*3+1+(i*3)]<<" "<<udata[j*xsz*3+2+(i*3)]<<"\n";
		pixel = qRgb(udata[yshift+2],udata[yshift+1],udata[yshift]);
		img.setPixel( i,ysz- j-1, pixel );
		}
	}
	graphicsScene->clear();
	graphicsScene->addPixmap(QPixmap::fromImage(img));
	graphicsView->update();
  graphicsView->setBackgroundBrush(QBrush (QColor ( 255, 255, 255,255 ) ));
}


ThreadRunner::ThreadRunner(string* datapointer,MainWindow *p)
{ imagedata = datapointer;
 wp =p;
}

void ThreadRunner::run()
{

}

void MainWindow:: ipsx_changed(int imagePixelSizeX_par) 
{

 graphicsScene->clear();
 for(int i=ipsx_spb->value();i<ipsy_spb->value();i++){
  //cout << imena_po_oblastyah[obl][i].toStdString()<<"\n";
 // graphicsScene->addPolygon(polygs[i],QPen(QColor(255,0,0,255)));

  cout << punkty[i].toStdString()<<"\n";
  for(int ip=0;ip<(int)polygs2[i].size();ip++)
  {graphicsScene->addPolygon(polygs2[i][ip],QPen(QColor(255,0,0,255)));
  }

 }
 fflush(stdout);
/*
 imagePixelSizeX = imagePixelSizeX_par;
 imageAngleSizeY = imageAngleSizeX*((double)imagePixelSizeY/(double)imagePixelSizeX);
 iasy_spb->setValue(imageAngleSizeX*((double)imagePixelSizeY/(double)imagePixelSizeX));*/
}
void MainWindow:: ipsy_changed(int imagePixelSizeY_par) 
{ graphicsScene->clear();
 for(int i=ipsx_spb->value();i<ipsy_spb->value();i++){
  //cout << imena_po_oblastyah[obl][i].toStdString()<<"\n";
  //graphicsScene->addPolygon(polygs[i],QPen(QColor(255,0,0,255)));

  cout << punkty[i].toStdString()<<"\n";
  for(int ip=0;ip<(int)polygs2[i].size();ip++)
  {graphicsScene->addPolygon(polygs2[i][ip],QPen(QColor(255,0,0,255)));
  }

 }
 fflush(stdout);
 /* imagePixelSizeY = imagePixelSizeY_par;
 imageAngleSizeY = imageAngleSizeX*((double)imagePixelSizeY/(double)imagePixelSizeX);
 iasy_spb->setValue(imageAngleSizeX*((double)imagePixelSizeY/(double)imagePixelSizeX));
 */
}
void MainWindow:: iasx_changed(double imageAngleSizeX_par) {imageAngleSizeX = imageAngleSizeX_par;}
void MainWindow:: iasy_changed(double imageAngleSizeY_par) {imageAngleSizeY = imageAngleSizeY_par;}
void MainWindow:: centFreq_changed(double centerFrequency_par) {centerFrequency = centerFrequency_par;}
void MainWindow:: k_changed(double k_par) {k = k_par;}
void MainWindow:: pyrThr_changed(double pyramidThreshold_par) {pyramidThreshold = pyramidThreshold_par;}
void MainWindow:: pyrDmax_changed(double pyramidDmax_par) {pyramidDmax = pyramidDmax_par; }
void MainWindow:: pyrNumIt_changed(int pyramidNumIterations_par) {pyramidNumIterations = pyramidNumIterations_par;}
void MainWindow:: mergeMax_changed(double mergeDMax_par) {mergeDMax = mergeDMax_par;}
void MainWindow:: mergeThr_changed(double mergeThreshold_par) {mergeThreshold = mergeThreshold_par;}
void MainWindow:: fltrMin_changed(int filterMin_par) {filterMin = filterMin_par;}
void MainWindow:: fltrMax_changed(int filterMax_par) {filterMax = filterMax_par;}
void MainWindow:: lambda_changed(double lambda_par) {lambda = lambda_par;}


void MainWindow:: runPressed()
{ if (! file_name.isEmpty()) 
  {
  // graphicsScene->clear();
   graphicsScene->addSimpleText(QString("Computing... Please wait."));
   graphicsView->update();
   runIIP();
  }
  else chooseFile();
}

void MainWindow:: putDefaults()
{
 imageAngleSizeX = imagePixelSizeX / imageAngleSizeXcoeff;
 imageAngleSizeY = imageAngleSizeX*((double)imagePixelSizeY/(double)imagePixelSizeX);//imageAngleSizeX * 0.75; // ratio 4:3
 iasx_spb->setValue(imagePixelSizeX/imageAngleSizeXcoeff);
 iasy_spb->setValue(imageAngleSizeX*((double)imagePixelSizeY/(double)imagePixelSizeX));
 //imagePixelSizeX / 64.0 * 2.0; // because 64 pixels equal 2 degree
 graphicsScene->clear();
}

void MainWindow::vsplitterMoved(int pos,int indx)
{ int h = vSplitter->geometry().height();
  QList<int> szs = vSplitter->sizes();
  double sc1l= (szs[0]-5)/((double)imagePixelSizeX);
  double sc1r= (szs[1]-5)/((double)imagePixelSizeX);
  double sc2= h/((double)imagePixelSizeY);
  double scl = sc1l; if (sc2<sc1l) scl= sc2;
  double scr = sc1r; if (sc2<sc1r) scr= sc2;
  //c out << "scr=" <<scr<<" ";
 if(szs[0]>10)
{
  graphicsView0->scale(scl/scale0,scl/scale0);
  graphicsView0->update();
 //c out << "sh"<<vSplitter->sizeHint().width()<<" ";
  scale0=scl;
}
 if(szs[1]>10)
{
  graphicsView->scale(scr/scale1,scr/scale1);
  graphicsView->update();
  //c out << "res "<< scr/scale1 <<" ";
  scale1=scr;
}
}

void MainWindow::resizeV1(double sc)
{ 
  graphicsView0->scale(sc/scale0,sc/scale0);

 //l1->addWidget(fr);
  //graphicsView0->setSizePolicy ( QSizePolicy::Preferred, QSizePolicy::Preferred );
  //graphicsView0->resize(700*sc,480*sc);
 //graphicsView0->setScene(graphicsScene0);
  graphicsView0->update();
 //c out << "sh"<<vSplitter->sizeHint().width()<<" ";
 scale0=sc;
}

void MainWindow::setECoords(int nEs,double* xCoords, double* yCoords, double* ars)
{nEllipses = nEs;
 if(ellipsesXs!=NULL) delete[] ellipsesXs;
 if(ellipsesYs!=NULL) delete[] ellipsesYs;
 if(ellipsesAreas!=NULL) delete[] ellipsesAreas;
 ellipsesXs = new double[nEs];
 ellipsesYs = new double[nEs];
 ellipsesAreas = new double[nEs];
 for(int i=0;i<nEs;i++)
 { ellipsesXs[i] = xCoords[i];
   ellipsesYs[i] = yCoords[i];
   ellipsesAreas[i] = ars[i];
 }
 //c out << "gotCoords\n";
 pathAct->setEnabled(true);
 drawAttentionMapAct->setEnabled(true);
 pathSaveAct->setEnabled(true);
 saveImageFiles0Act->setEnabled(true);
 saveImageFiles1Act->setEnabled(true);
}
void MainWindow::scanPath()
{
 double ckld = (double)imagePixelSizeXd / 30.0;
 double r=ckld*0.5;
 double shX,shY; shX = (double)imagePixelSizeXd/2.0; shY = (double)imagePixelSizeYd/2.0;
 double prevx, prevy; prevx=0; prevy=0;
 //c out << "VAM fixations\nX    Y   Area\n";
 if (nEllipses>0)
 {
  for (int i=0; i<nEllipses; i++)
  {
   double pixx = ellipsesXs[i]*imageAngleSizeXcoeff+shX-r;
   double pixy = shY + (ellipsesYs[i]*imageAngleSizeXcoeff)-r;
   for(int j = 0;j<1;j++)
   {
    QGraphicsEllipseItem * e1 =  graphicsScene->addEllipse(QRectF(0,0,ckld,ckld));
    e1->setPos(pixx,pixy);
    e1->setZValue(j+1);
    //graphicsScene->addSimpleText(QString("%1").arg(i+1))->setPos(pixx,pixy);
    QBrush  brsh = graphicsScene->foregroundBrush();

    QGraphicsSimpleTextItem * st1= graphicsScene->addSimpleText(QString("%1").arg(i+1));
    st1->setBrush(QColor(255, 255, 0, 127));
    st1->setPos(r/4+pixx,r/4+pixy); st1->setZValue(j+10);
    QGraphicsEllipseItem * e2 = graphicsScene->addEllipse(QRectF(0,0,ckld-2,ckld-2),
    QPen(QColor( 255, 255, 255,255 ),1.0));
    e2->setPos(pixx+1,pixy+1);
    e2->setZValue(j+1);
 // c out << pixx<<" "<<pixy<< " " << ellipsesAreas[i] <<"\n";
   }

   if(i>0)//drawing lines
   {
    double x1= prevx+r; double y1= prevy+r;
    double x2= pixx+r; double y2= pixy+r;
    double L =sqrt((x2-x1)*(x2-x1)+((y2-y1)*(y2-y1)));
    double cosa= (x2-x1)/L; double sina=(y2-y1)/L;
    double a1 = r*cosa+x1; double b1 = r*sina+y1;
    double a2 =x2 - (r*cosa); double b2 = y2 - (r*sina);
    double xx1 = a1 +(1*sina); double yy1 = b1 -(1*cosa);
    double xx2 = a2 +(1*sina); double yy2 = b2 -(1*cosa);
    QGraphicsLineItem * l1 = graphicsScene->addLine(a1,b1,a2,b2,QPen(QColor( 255, 255, 255,128 ),1.0));
    l1->setZValue(5);
    QGraphicsLineItem * l2 = graphicsScene->addLine(xx1,yy1,xx2,yy2,QPen(QColor( 0, 0, 0,128 ),1.0));
    l2->setZValue(5);
   }
  prevx=pixx;prevy=pixy;
  }// c out << "end of VAM fixations\n";
 }
 graphicsView->update();
 QString fileName;
 fileName  = QFileDialog::getOpenFileName(this, tr("Load scanpath data"),"./",tr(" (*.* *.* *)"));
     //else fileName  = QFileDialog::getOpenFileName(ourWidget, tr("Load list of pairs of edges"),"./",tr("(*.* *)"));
    if (fileName.isEmpty())
    return;

    ifstream afile (fileName.toStdString().c_str());
  if (!afile.is_open())
  {
        QString msg = tr("Failed to open %1\n%2")
                        .arg(fileName);
                        //.arg(file.errorString());
        QMessageBox::warning(this, tr("Error"), msg);
        return;
    }
   vector <double> exs;
   vector <double> eys;
  vector <double> dts;
    while ( afile.good() )
    {string line;
      getline (afile,line);
      //cout << line << endl;
     string cmp("EFIX R");
     if(line.compare(0, cmp.length(), cmp) == 0)
     {
      char buffer[line.length()-6];
      size_t length=line.copy(buffer,line.length()-7,7);
      buffer[length]='\0';
      istringstream iss(buffer);
      double value; iss >> value; iss >> value;
      iss >> value; exs.push_back(value);//SHIFT -255, temporary    <-- ACHTUNG!!!
      iss >> value; eys.push_back(value-81);//SHIFT -75, temporary      <-- ACHTUNG!!!
      iss >> value; dts.push_back(value);
     }
    }
    afile.close();
 double r_prev=0;
 for (uint i=0; i<exs.size(); i++)
 {//double prevx, prevy; prevx=0; prevy=0;
 
  ckld=sqrt(dts[i])*2.5; r= ckld*0.5;
  double pixx = exs[i]-r;
  double pixy = eys[i]-r;
  for(int j = 0;j<1;j++)
   {
    QGraphicsEllipseItem * e1 =  graphicsScene0->addEllipse(QRectF(0,0,ckld,ckld));
    e1->setPos(pixx,pixy);
    e1->setZValue(j+1);
    QGraphicsSimpleTextItem * st1= graphicsScene0->addSimpleText(QString("%1").arg(i+1));
    st1->setBrush(QColor(255,255,0,127));
    st1->setPos(r/4+pixx,r/4+pixy); st1->setZValue(j+1);
    QGraphicsEllipseItem * e2 = graphicsScene0->addEllipse(QRectF(0,0,ckld-2,ckld-2),
    QPen(QColor( 255, 255, 255,255 ),1.0));
    e2->setPos(pixx+1,pixy+1);
    e2->setZValue(j+1);
   }//->setZValue(10);
 
 if(i>0)//drawing lines
   {
    double x1= prevx+r_prev; double y1= prevy+r_prev;
    double x2= pixx+r; double y2= pixy+r;
    double L =sqrt((x2-x1)*(x2-x1)+((y2-y1)*(y2-y1)));
    double cosa= (x2-x1)/L; double sina=(y2-y1)/L;
    double a1 = r_prev*cosa+x1; double b1 = r_prev*sina+y1;
    double a2 =x2 - (r*cosa); double b2 = y2 - (r*sina);
    double xx1 = a1 +(1*sina); double yy1 = b1 -(1*cosa);
    double xx2 = a2 +(1*sina); double yy2 = b2 -(1*cosa);
    QGraphicsLineItem * l1 = graphicsScene0->addLine(a1,b1,a2,b2,QPen(QColor( 255, 255, 255,128 ),1.0));
    l1->setZValue(5);
    QGraphicsLineItem * l2 = graphicsScene0->addLine(xx1,yy1,xx2,yy2,QPen(QColor( 0, 0, 0,128 ),1.0));
    l2->setZValue(5);
   }
  prevx=pixx;prevy=pixy;
  r_prev=r;
 }
  graphicsView0->update();
}

void MainWindow::saveScanPath()
{
 QString fn = QString(file_name);
 fn.replace(".bmp", "_protoSP.txt", Qt::CaseInsensitive);
 fn = QFileDialog::getSaveFileName(this, tr("Save protoobjects scan path"),fn,tr("text files (*.TXT *.txt)"));
 if (fn.isEmpty()) return;
 FILE * fp = fopen(fn.toAscii().data(),"w");
 for (int i=0;i<nEllipses;i++)
 {double x = ellipsesXs[i]*imageAngleSizeXcoeff+((double)imagePixelSizeXd/2.0);
  double y = ellipsesYs[i]*imageAngleSizeXcoeff+((double)imagePixelSizeYd/2.0);
  fprintf(fp,"%0.3f %0.3f %0.3f\n", x,y,ellipsesAreas[i]);
 }
 fclose(fp);
 //c out << "saving Path ";
}

void MainWindow::saveImageFiles0() {saveImageFiles(0);}
void MainWindow::saveImageFiles1() {saveImageFiles(1);}
void MainWindow::saveImageFiles(int which_scene)
{
//File output png
 QPixmap pm(imagePixelSizeXd,imagePixelSizeYd);
         pm.fill(QColor(255,255,255,255) );
         QPainter painter;
         painter.begin(&pm);
         painter.setRenderHint(QPainter::Antialiasing);
     painter.setRenderHint(QPainter::SmoothPixmapTransform);
     QGraphicsScene * sc;
     if(which_scene==0) sc = graphicsScene0;
     else sc = graphicsScene;
     //graphicsView->render(&painter);
     sc->render(&painter);
     painter.end();
         //c out << "print1\n";fflush(stdout);
         QByteArray bytes;
         QBuffer buffer(&bytes);
         buffer.open(QIODevice::WriteOnly);
         pm.save(&buffer, "png");
         //c out << "print2\n";fflush(stdout);	 
  //if(im_png)
  { QString fn = QString(file_name);
    fn.replace(".bmp", "", Qt::CaseInsensitive);  if(which_scene==1) fn=fn+QString("_proto");
   QString imageFileName  = QFileDialog::getSaveFileName
   (this, QString("Save PNG image"),fn+QString(".png"),QString("PNG files (*.PNG *.png)"));
    if (!imageFileName.isEmpty())
       {
         QFile *  imageFile = new QFile(imageFileName);
         if (imageFile->open(QFile::WriteOnly))
     {imageFile->write(buffer.data());

     imageFile->close();
         }
         else
        {
        QString msg = tr("Failed to open %1\n%2")
                        .arg(imageFileName)
                        .arg((*imageFile).errorString());
        QMessageBox::warning(this, tr("Error"), msg);
        }

       }
  }
  //if(im_svg)
  {
   QSvgGenerator * svg_gen = new  QSvgGenerator();
    QString fn = QString(file_name);
    fn.replace(".bmp", "", Qt::CaseInsensitive); if(which_scene==1) fn=fn+QString("_proto");

   QString imageFileName2  = QFileDialog::getSaveFileName
    (this, QString("Save SVG image"),fn+QString(".svg"),QString("SVG files (*.SVG *.svg)"));
   if (!imageFileName2.isEmpty())
   {
     svg_gen->setFileName (imageFileName2);
         svg_gen->setSize(QSize(imagePixelSizeXd,imagePixelSizeYd));
         
         pm.fill(QColor(250,250,250,255) );
         QPainter painter2;//= new QPainter::QPainter(); //(pe-> paintDevice());
        if(! painter2.begin(svg_gen))
        {
         QString msg = tr("Failed to open %1\n")
                        .arg(imageFileName2);
         QMessageBox::warning(this, tr("Error"), msg);
        } 
        else
        {painter2.setRenderHint(QPainter::Antialiasing);
     painter2.setRenderHint(QPainter::SmoothPixmapTransform);
     QGraphicsScene * sc2;
     if(which_scene==0) sc2 = graphicsScene0;
     else sc2 = graphicsScene;
         //if(viewmode!=1)sc2->setBackgroundBrush(Qt::white);
     sc2->render(&painter2);
     painter2.end();
        }
   }

 }
}

void MainWindow::drawAttentionMap()
{
  QString fileName;
 fileName  = QFileDialog::getOpenFileName(this, tr("Load scanpath data"),"./",tr(" (*.* *.* *)"));
     //else fileName  = QFileDialog::getOpenFileName(ourWidget, tr("Load list of pairs of edges"),"./",tr("(*.* *)"));
    if (fileName.isEmpty())
    return;

    ifstream afile (fileName.toStdString().c_str());
  if (!afile.is_open())
  {
        QString msg = tr("Failed to open %1\n%2")
                        .arg(fileName);
                        //.arg(file.errorString());
        QMessageBox::warning(this, tr("Error"), msg);
        return;
    }
   vector <double> exs;
   vector <double> eys;
  vector <double> dts;
    while ( afile.good() )
    {string line;
      getline (afile,line);
      //cout << line << endl;
     string cmp("EFIX R");
     if(line.compare(0, cmp.length(), cmp) == 0)
     {
      char buffer[line.length()-6];
      size_t length=line.copy(buffer,line.length()-7,7);
      buffer[length]='\0';
      istringstream iss(buffer);
      double value; iss >> value; iss >> value;
      iss >> value; exs.push_back(value);//SHIFT -255, temporary    <-- ACHTUNG!!!
      iss >> value; eys.push_back(value-81);//SHIFT -75, temporary      <-- ACHTUNG!!!
      iss >> value; dts.push_back(value);
     }
    }
    afile.close();
 int numFixations = exs.size();//10;//exs.size();
 double e = 2.7182817;
 float thresh = 0.6f;
 float brightBasis = 0.18f;
 float h = 0.0f;
 int opacity = 120;

// ***************************************************
// * data for Sony Multiscan 20sfII *
// * screen_Length_Horizontal = 36,5 cm *
// * screen_Length_Vertical = 28,0 cm *
// * screen_Resolution_Horizontal = 1024 pixel *
// * screen_Resolution_Vertical = 768 pixel *
// ================================================
// * attentional map: attention circle with radius *
// * of nearly 1 cm = 28 pixel in horizontal direc *
// * according to Marc's Master Thesis chose this *
// * value as sigma in the following formula *
// ***************************************************
  double sigma = 28.0;
  int zweiSigma = (int) (3.0 * sigma);
  double sigmaTerm = 2.0 * pow(sigma, 2.0);
  // double maxGes = 0.0, minGes = 0.0; // min, max for attentional map
  // set min and max to highest/smallest double value
  double maxGes = pow(10.0, 308.0) * (-1.0);
  double minGes = pow(10.0, 308.0);
 // double gVal = 0.0;
  // double[][] gGes; // sum of single Gauss functions
  // create dynamic array to hold attentional map
  // attentionMap = new double*[IMAGE_SIZE_X];
  // double[][] attentionMap = new double[imgWidth][imgHeight];
  double** gGes;
  gGes = new double* [imagePixelSizeXd];
  for (int k = 0; k< imagePixelSizeXd; k++)
     gGes[k] = new double [imagePixelSizeYd];

  for (int i = 0; i < imagePixelSizeXd; i++)
   for (int j = 0; j < imagePixelSizeYd; j++) gGes[i][j] = 0.0;

        // calculate gauss for each image point
  int attenMapInd = 0, fixX = 0, fixY = 0, fixD = 0, vecInd = 0;
 // int maxRun = numFixations / 3;



 for (unsigned int j = 0; j <exs.size() ; j++)
 { fixX = exs[j];
   fixY = eys[j];
   fixD = dts[j];
   // calculate Gaussian only for square of size zweiSigma around
   // fixation (95% of the values)
   // *********************************
   // * calculate ATM Array **
   // *********************************
   for (int x = fixX - zweiSigma; x <= fixX + zweiSigma; x++) {
    for (int y = fixY - zweiSigma; y <= fixY + zweiSigma; y++) {

     if ((x >= 0 && x < imagePixelSizeXd) && (y >= 0 && y < imagePixelSizeYd)) {
      double val = (pow((double) (x - fixX), 2.0) + pow((double) (y - fixY), 2.0)) / sigmaTerm;
      val *= -1;
      // multiply gauss value with fixation duration
      double gVal = (pow(e, val) * fixD);
      gGes[x][y] += gVal;
      if (gGes[x][y] < minGes)
       minGes = gGes[x][y];
      if (gGes[x][y] > maxGes)
       maxGes = gGes[x][y];
     }
    } // end of y
   } // end of x
 } // for (j=0,...) loop

  double attMapMax = 0.0;
  for (int y = 0; y < imagePixelSizeYd; y++) {
   for (int x = 0; x < imagePixelSizeXd; x++) {
    gGes[x][y] = ((gGes[x][y] - minGes) / (maxGes - minGes));
   // add up values for avg ATM-Map
   //if (avgATM.isSelected()) {
   //<---->avgATMArray[x][y] += gGes[x][y];
   //} // if avgATM
   // get maximum of entries
  if (gGes[x][y] > attMapMax)
  attMapMax = gGes[x][y];
   }
  }


  QPixmap pm(imagePixelSizeXd,imagePixelSizeYd);
  pm.fill(QColor(255,255,255,255) );
  QPainter painter;
  painter.begin(&pm);
  painter.setRenderHint(QPainter::Antialiasing);
  painter.setRenderHint(QPainter::SmoothPixmapTransform);
  QGraphicsScene * sc;
    // if(which_scene==0) sc = graphicsScene0;
    // else 
  sc = graphicsScene0;
  sc->render(&painter);
  painter.end();
  QImage image = pm.toImage();

  double red = 0.0, green = 0.0, blue = 0.0, th = 0.0;
  int rgbVal = 0;
  int rval = 0, gval = 0, bval = 0;
  QRgb color= qRgba(0,0,0,127);
  double thMax=0; double thavg=0; int cnt=0;    // calc attentionMap for single image
  for (int y = 0; y < imagePixelSizeYd; y++){
   for (int x = 0; x < imagePixelSizeXd; x++) {
     if (numFixations > 0)
      th = h + (1 - h) * (gGes[x][y] / attMapMax);
     else
      th = brightBasis;
     if(th<0)th=0;
     cnt++; thavg=thavg+th;
     if(thMax<th)thMax=th;
     color = getHeatColor((float) th, color);
     rval = qRed(color);
     gval = qGreen(color);
     bval = qBlue(color);
     int ir = qRed(image.pixel(x,y));
     int ig = qGreen(image.pixel(x,y));
     int ib = qBlue(image.pixel(x,y));
     double alpha=0.5;//0.7*pow(th,0.4);
     int nr = (int)(((double)rval) * alpha+((double)ir *(1- alpha))); if (nr>255)nr=255;
     int ng = (int)(((double)gval) * alpha+((double)ig *(1- alpha))); if (ng>255)ng=255;
     int nb = (int)(((double)bval) * alpha+((double)ib *(1- alpha))); if (nb>255)nb=255;
     image.setPixel(x,y,(unsigned int) (((((0 * 256) + nr) * 256) + ng) * 256)+ nb);
   } // x
 } // y

/// Prototypes image
  maxGes = pow(10.0, 308.0) * (-1.0);
  minGes = pow(10.0, 308.0);
  double** gGes1;
  gGes1 = new double* [imagePixelSizeXd];
  for (int k = 0; k< imagePixelSizeXd; k++)
     gGes1[k] = new double [imagePixelSizeYd];

  for (int i = 0; i < imagePixelSizeXd; i++)
   for (int j = 0; j < imagePixelSizeYd; j++) gGes1[i][j] = 0.0;

 double shX,shY; shX = (double)imagePixelSizeXd/2.0; shY = (double)imagePixelSizeYd/2.0;
 for (unsigned int j = 0; j <nEllipses ; j++)
 { fixX = ellipsesXs[j]*imageAngleSizeXcoeff+shX;
   fixY = ellipsesYs[j]*imageAngleSizeXcoeff+shY;
   fixD = 1000;//dts[j]; c out << fixX <<" "<<fixY<<"\n";
   for (int x = fixX - zweiSigma; x <= fixX + zweiSigma; x++) {
    for (int y = fixY - zweiSigma; y <= fixY + zweiSigma; y++) {
     if ((x >= 0 && x < imagePixelSizeXd) && (y >= 0 && y < imagePixelSizeYd)) {
      double val = (pow((double) (x - fixX), 2.0) + pow((double) (y - fixY), 2.0)) / sigmaTerm;
      val *= -1;
      double gVal = (pow(e, val) * fixD);
      gGes1[x][y] += gVal;
      if (gGes1[x][y] < minGes)
       minGes = gGes1[x][y];
      if (gGes1[x][y] > maxGes)
       maxGes = gGes1[x][y];
     }
    } // end of y
   } // end of x
 } // for (j=0,...) loop

  double attMapMax1 = 0.0;
  for (int y = 0; y < imagePixelSizeYd; y++) {
   for (int x = 0; x < imagePixelSizeXd; x++) {
    gGes1[x][y] = ((gGes1[x][y] - minGes) / (maxGes - minGes));
   // add up values for avg ATM-Map
   //if (avgATM.isSelected()) {
   //<---->avgATMArray[x][y] += gGes[x][y];
   //} // if avgATM
   // get maximum of entries
  if (gGes1[x][y] > attMapMax1)
  attMapMax1 = gGes1[x][y];
   }
  }


  QPixmap pm1(imagePixelSizeXd,imagePixelSizeYd);
  pm1.fill(QColor(255,255,255,255) );
  QPainter painter1;
  painter1.begin(&pm1);
  painter1.setRenderHint(QPainter::Antialiasing);
  painter1.setRenderHint(QPainter::SmoothPixmapTransform);
  QGraphicsScene * sc1;
    // if(which_scene==0) sc = graphicsScene0;
    // else 
  sc1 = graphicsScene;
  sc1->render(&painter1);
  painter1.end();
  QImage image1 = pm1.toImage();

  red = 0.0; green = 0.0; blue = 0.0; th = 0.0;
  rgbVal = 0;
  rval = 0; gval = 0; bval = 0;
  color= qRgba(0,0,0,127);
  thMax=0;  thavg=0;  cnt=0;    // calc attentionMap for single image
  for (int y = 0; y < imagePixelSizeYd; y++){
   for (int x = 0; x < imagePixelSizeXd; x++) {
     if (numFixations > 0)
      th = h + (1 - h) * (gGes1[x][y] / attMapMax1);
     else
      th = brightBasis;
     if(th<0)th=0;
     cnt++; thavg=thavg+th;
     if(thMax<th)thMax=th;
     color = getHeatColor((float) th, color);
     rval = qRed(color);
     gval = qGreen(color);
     bval = qBlue(color);
     int ir = qRed(image1.pixel(x,y));
     int ig = qGreen(image1.pixel(x,y));
     int ib = qBlue(image1.pixel(x,y));
     double alpha=0.5;//0.7*pow(th,0.4);
     int nr = (int)(((double)rval) * alpha+((double)ir *(1- alpha))); if (nr>255)nr=255;
     int ng = (int)(((double)gval) * alpha+((double)ig *(1- alpha))); if (ng>255)ng=255;
     int nb = (int)(((double)bval) * alpha+((double)ib *(1- alpha))); if (nb>255)nb=255;
     image1.setPixel(x,y,(unsigned int) (((((0 * 256) + nr) * 256) + ng) * 256)+ nb);
   } // x
 } // y

//Bypixel comparison
 double dist=0.0;
 double sumThMin=0.0;  double sumThMax=0.0;
  for (int y = 0; y < imagePixelSizeYd; y++)
   for (int x = 0; x < imagePixelSizeXd; x++) 
  {  double th0 =(1 - h) * (gGes[x][y] / attMapMax)+h; if(th0<0)th0=0.0;
     double th1 =(1 - h) * (gGes1[x][y] / attMapMax1)+h; if(th1<0)th1=0.0;
     if((th0+th1)==0) dist=dist+1.0;
     else dist = dist + (th0 -th1)*(th0 -th1)/(th0+th1);
     if(th0<th1) {sumThMin+=th0; sumThMax+=th1;}
     else  {sumThMin+=th1; sumThMax+=th0;}
  }

 dist=sqrt(dist)/(imagePixelSizeXd*imagePixelSizeYd);

//cout << "dist is: "<< dist <<" sums prop. is "<<sumThMin/sumThMax  << "\n";
 //QString msg = QObject::tr("Distance is %1\nSimilarity is %2") .arg(dist).arg(sumThMin/sumThMax);
  //QMessageBox::information(this, QObject::tr("Distance&Similarity"), msg  );

 for (int k = 0; k < imagePixelSizeYd; k++) delete gGes[k];
 delete[] gGes;
 for (int k = 0; k < imagePixelSizeYd; k++) delete gGes1[k];
 delete[] gGes1;
 cout << "max "<<thMax<<  " avg "<<thavg/cnt <<"\n";
 // store ATM image
   //image->save("ATM.png","PNG");
 //<---->QGraphcsScene *  gs2 = new QGraphcsScene();
  pm = QPixmap::fromImage(image);
  graphicsScene0->clear();
  graphicsScene0->addPixmap(pm);
  graphicsView0->update();

  pm1 = QPixmap::fromImage(image1);
  graphicsScene->clear();
  graphicsScene->addPixmap(pm1);
  graphicsView->update();


cout << "dist is: "<< dist <<" sums prop. is "<<sumThMin/sumThMax  << "\n";
 QString msg = QObject::tr("Distance is %1\nSimilarity is %2") .arg(dist).arg(sumThMin/sumThMax);
  QMessageBox::information(this, QObject::tr("Distance&Similarity"), msg  );


cout << "ATM\n";
}

QRgb MainWindow::getHeatColor(float val, QRgb myColor)
{       QRgb color=NULL;
        if(isnan(val)) {
	color = qRgba(0,0,0,0);//qRed(myColor) = 0; qBlue(myColor) = 0; qGreen(myColor) = 0;
	return color;
	}	// val is ATM value : 0 low attention , 1 high attention
	int rval, gval, bval;
	int i = 0;
	float f;
	f = ((255 * 4) * (1 - val));
	i = (int) f; // 0 -255*3 	// wenn attMap(val) hoch, dann i klein - rote Farbe
	if (i >= 0 && i < 255) // ( atm values 0.75 - 1.0) - Rot Ton
	{	    // Interval 1: hohe ATM-Werte	    // zieht von rot nach gelb
	    rval = 255;
	    gval = i;
	    bval = 0;
	} else
	if (i >= 255 && i < (255 * 2)) // atm values 0.5-0.75) - Gelb Ton
	{	    // zieht von gelb nach gr�n
	    rval = 255 - (i - 255);
	    gval = 255;
	    bval = 0; 	    // rval = 255-(i-255);	    // gval = 255*2-(i);	    // bval = 0;
	} else
	if (i >= (255 * 2) && i <= (255 * 3)) // atm value (0.25 - 0.5) Schwarz	// Ton
	{    // von gr�n nach blau
	    rval = 0;
	    gval = 255 - (i - 255 * 2);
	    bval = (i - 255 * 2);// / Kein Gruener Hintergrund // bval = 0;
	} else
	if (i >= (255 * 3) && i <= (255 * 4)) { // von Blau nach schwarz // zeichnet verschiedene Blaut�ne bei kleineren ATM-Werten
	    rval = 0;
	    gval = 0;
	    bval = 255 - (i - 255 * 3);
	} else {    // sonst schwarz
	    rval = 0;
	    gval = 0;
	    bval = 0;}
	color = qRgba(rval,gval,bval,127);
	return color;
} // end of getHeatColor

void MainWindow::run_oocva()
{
 // o ocva(graphicsScene0,graphicsScene, imagePixelSizeXd,imagePixelSizeYd,4,200,3,80,650,50,800,imagePixelSizeXd,imagePixelSizeYd);
  saveImageFiles1Act->setEnabled(true);
}

void MainWindow::run_oocva_cfg()
{
  //o ocva(graphicsScene0,graphicsScene, imagePixelSizeXd,imagePixelSizeYd,  epsilon_spb->value(),t_spb->value(),m_spb->value(),threshold_spb->value(),vaThresh_spb->value(),sbBlockThresh_spb->value(),S_spb->value(),  salMapW_spb->value(),salMapH_spb->value());
  saveImageFiles1Act->setEnabled(true);
}


void MainWindow::run_oocva_dlg()
{if(oocva_dlg==NULL)
 {oocva_dlg = new QFrame();
  epsilon_spb =new  QSpinBox();
  epsilon_spb->setMaximum(100);
  epsilon_spb->setMinimum(1);
  epsilon_spb->setValue(4);
  t_spb = new QSpinBox();
  t_spb->setMaximum(2000);
  t_spb->setMinimum(1);
  t_spb->setValue(200);
  m_spb = new QSpinBox();
  m_spb->setMaximum(100);
  m_spb->setMinimum(1);
  m_spb->setValue(3);
  threshold_spb= new QSpinBox();
  threshold_spb->setMaximum(800);
  threshold_spb->setMinimum(1);
  threshold_spb->setValue(80);
  vaThresh_spb= new QSpinBox();
  vaThresh_spb->setMaximum(2000);
  vaThresh_spb->setMinimum(1);
  vaThresh_spb->setValue(650);
  sbBlockThresh_spb= new QSpinBox();
  sbBlockThresh_spb->setMaximum(1000);
  sbBlockThresh_spb->setMinimum(1);
  sbBlockThresh_spb->setValue(50);
  S_spb= new QSpinBox();
  S_spb->setMaximum(2000);
  S_spb->setMinimum(1);
  S_spb->setValue(800);
    salMapW_spb= new QSpinBox();
  salMapW_spb->setMaximum(20000);
  salMapW_spb->setMinimum(5);
  salMapW_spb->setValue(imagePixelSizeXd);
   salMapH_spb= new QSpinBox();
  salMapH_spb->setMaximum(20000);
  salMapH_spb->setMinimum(5);
  salMapH_spb->setValue(imagePixelSizeYd);

  QLabel * eps_lbl=new QLabel("Epsilon");
  QLabel * t_lbl=new QLabel("t");
  QLabel * m_lbl=new QLabel("m");
  QLabel * thr_lbl=new QLabel("threshold");
  QLabel * vaThr_lbl=new QLabel("vaThreshold");
  QLabel * sbBl_lbl=new QLabel("sbBlockThreshold");
  QLabel * S_lbl=new QLabel("S");
  QLabel * salMapW_lbl=new QLabel("scale map width to ");
  QLabel * salMapH_lbl=new QLabel("scale map height to ");


  QGridLayout * glo = new QGridLayout();

  glo->addWidget(epsilon_spb,0,1);
  glo->addWidget(eps_lbl,0,0);
  glo->addWidget(t_spb,1,1);
  glo->addWidget(t_lbl,1,0);
  glo->addWidget(m_spb,2,1);
  glo->addWidget(m_lbl,2,0);
  glo->addWidget(threshold_spb,3,1);
  glo->addWidget(thr_lbl,3,0);
  glo->addWidget(vaThresh_spb,4,1);
  glo->addWidget(vaThr_lbl,4,0);
  glo->addWidget(sbBlockThresh_spb,5,1);
  glo->addWidget(sbBl_lbl,5,0);
  glo->addWidget(S_spb,6,1);
  glo->addWidget(S_lbl,6,0);
  glo->addWidget(salMapW_lbl,7,0);
  glo->addWidget(salMapW_spb,7,1);
  glo->addWidget(salMapH_lbl,8,0);
  glo->addWidget(salMapH_spb,8,1);


  connect(salMapW_spb,SIGNAL(valueChanged(int)),this,SLOT(salMapWSpb_changed(int)  ));

  QPushButton * bRun = new QPushButton(tr("Run"));
  connect(bRun,SIGNAL(pressed()),this,SLOT(run_oocva_cfg()));
  glo->addWidget(bRun,9,1);
  oocva_dlg->setLayout(glo);
  oocva_dlg->show();
 }
 else
  oocva_dlg->show();
}

void MainWindow::call_pathSim()
{
  //pathSim(graphicsScene0,graphicsScene, imagePixelSizeXd,imagePixelSizeYd);
}
void MainWindow::salMapWSpb_changed(int suggW)
{ salMapH_spb->setValue(imagePixelSizeYd*suggW/imagePixelSizeXd); //Yd/Xd=Y/X Y/Yd=X/Xd Y=Yd*(X/Xd)

}

void MainWindow::pathSim(QGraphicsScene * sc,QGraphicsScene * sc2, int imW, int imH) {}



void MainWindow::imageDialog()
{
QDialog idlg;
 QPushButton *  submitButton = new QPushButton(tr("Submit"));
     submitButton->setDefault(true);
 QPushButton *   cancelButton = new QPushButton(tr("&Cancel"));
 QSpinBox * spBox = new QSpinBox();
 QLabel * lbl1;
 lbl1 = new QLabel("image side, pixels:");
 spBox->setMaximum(7000);
 spBox->setSingleStep(200);
 spBox->setMinimum(100);
 spBox->setValue(im_side);
 QDialogButtonBox *  buttonBox = new QDialogButtonBox(Qt::Horizontal);
 buttonBox->addButton(submitButton, QDialogButtonBox::AcceptRole);
 buttonBox->addButton(cancelButton, QDialogButtonBox::RejectRole);
 QGridLayout * gridl = new QGridLayout();
 gridl->addWidget(lbl1,0,0);
 gridl->addWidget(spBox,0,1);
 QLabel * lbl2 = new QLabel("Save as PNG");
 QLabel * lbl3 = new QLabel("Save as SVG");
 QCheckBox * chb1 = new QCheckBox();
 QCheckBox * chb2 = new QCheckBox();
 gridl->addWidget(lbl2,1,0);
 gridl->addWidget(lbl3,2,0);
 gridl->addWidget(chb1,1,1);
 gridl->addWidget(chb2,2,1);
 chb1->setChecked(im_png);
 chb2->setChecked(im_svg);


 gridl->addWidget(buttonBox,3,0);
 idlg.setLayout(gridl);
 connect(cancelButton, SIGNAL(clicked()), &idlg, SLOT(close()));
 connect(submitButton, SIGNAL(clicked()), &idlg, SLOT(close()));
 connect(submitButton, SIGNAL(clicked()), this, SLOT(saveImageFiles()));
 connect(spBox, SIGNAL(valueChanged(int)), this,SLOT(getIm_sideSpin(int)));
 connect(chb1, SIGNAL(toggled(bool)), this,SLOT(png_toggled(bool)));
 connect(chb2, SIGNAL(toggled(bool)), this,SLOT(svg_toggled(bool)));
 idlg.exec();

}

void MainWindow::saveImageFiles()
{
//File output png
// QPixmap pm(im_side,im_side);
  QPixmap pm(1000,1000);
         pm.fill(QColor(255,255,255,255) );
         QPainter painter;
         painter.begin(&pm);
         painter.setRenderHint(QPainter::Antialiasing);
 painter.setRenderHint(QPainter::SmoothPixmapTransform);
 QGraphicsScene * sc = graphicsScene;//graphicsView->scene();
 //graphicsView->render(&painter);
 sc->render(&painter);
 painter.end();
         //c out << "print1\n";fflush(stdout);
         QByteArray bytes;
         QBuffer buffer(&bytes);
         buffer.open(QIODevice::WriteOnly);
         pm.save(&buffer, "png");
         //c out << "print2\n";fflush(stdout); 
  if(im_png)
  {QString imageFileName  = QFileDialog::getSaveFileName
   (this, QString("Save PNG image"),QString("Ukraine_colour_map.png"),QString("PNG files (*.PNG *.png)"));
    if (!imageFileName.isEmpty())
       {
         QFile *  imageFile = new QFile(imageFileName);
         if (imageFile->open(QFile::WriteOnly))
 {imageFile->write(buffer.data());
 
 imageFile->close();
         }
         else
        {
        QString msg = tr("Failed to open %1\n%2")
                        .arg(imageFileName)
                        .arg((*imageFile).errorString());
        QMessageBox::warning(this, tr("Error"), msg);
        }

       }
  }
  if(im_svg)
  {
         QSvgGenerator * svg_gen = new   QSvgGenerator();
   QString imageFileName2  = QFileDialog::getSaveFileName
    (this, QString("Save SVG image"),QString("Ukraine_colour_map.svg"),QString("SVG files (*.SVG *.svg)"));
   if (!imageFileName2.isEmpty())
   {
 svg_gen->setFileName (imageFileName2);
         svg_gen->setSize(QSize(im_side,im_side));
         
         pm.fill(QColor(250,250,250,255) );
         QPainter painter2;//= new QPainter::QPainter(); //(pe-> paintDevice());
        if(! painter2.begin(svg_gen))
        {
         QString msg = tr("Failed to open %1\n")
                        .arg(imageFileName2);
         QMessageBox::warning(this, tr("Error"), msg);
        } 
        else
        {painter2.setRenderHint(QPainter::Antialiasing);
 painter2.setRenderHint(QPainter::SmoothPixmapTransform);
 QGraphicsScene * sc2 = graphicsScene;//graphicsView->scene();
        // if(viewmode!=1)
        sc2->setBackgroundBrush(Qt::white);
 sc2->render(&painter2);
 painter2.end();
        }
   }

 }
}

void MainWindow::getIm_sideSpin(int newside) {im_side=newside;}
void MainWindow::png_toggled(bool state) {im_png=state;}
void MainWindow::svg_toggled(bool state) {im_svg=state;}



PolygonBrusher::PolygonBrusher(QVector <QGraphicsPolygonItem *>  itms,double initVal)
{p=itms;
 val=initVal;// c out <<"init"<<"\n";
}
void PolygonBrusher::rebrush(double newval)
{cout <<"new val"<<newval<<"\n";
 val=newval;
 for (int i=0;i<(int)p.size();i++)
 {int red=0,green=0,blue=0;
  if(newval<0) red=green=blue=255;
 else
 {
 double  mb_log= log((double)(101));

 int brightness=0;
     double dbri = log((double) (newval+1))/mb_log *255;brightness=(int)round(dbri);

     if(brightness<(36 )){blue=(int)round(3.2*brightness)+143;}
     if((brightness >=(36))&(brightness<(100 ))){blue=255; green=(int)round((brightness-36)*4);}
     if((brightness >=(100))&(brightness<(164 ))){blue=(int)round(255-(4*(brightness-100)));
                            green=255;red=(int)round(4*(brightness-100)); }
     if((brightness >=(164))&(brightness<(228 ))){ red=255;green=255-(int)round(4*(brightness-164)); }
     if((brightness >=(228))){red=(int)round(255 -(4*(brightness-228))); }

      if(blue>255)printf("_____wrong blue______ %d\n",brightness);     if(red>255){printf("red=%d ",red);red=255;}     if(red<0){printf("red=%d ",red); red=0;}     if(green>255){printf("green=%d ",green); green=255;}     if(green<0){printf("green=%d ",green); green=0;}     if(blue>255){printf("blue=%d ",blue); blue=255;}     if(blue<0){printf("blue=%d ",blue); blue=0;}
  }
 p[i]->setBrush(QColor(red,green,blue,255));
 }
}

void PolygonBrusher::changeItems(QVector <QGraphicsPolygonItem *> newItems)
{p=newItems;// cout <<"new Itm"<<"\n";
}

double PolygonBrusher::getDVal(){return val;}