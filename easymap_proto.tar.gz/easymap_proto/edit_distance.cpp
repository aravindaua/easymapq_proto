//#include <cassert>
#include <edit_distance.h>
#include <string>
//#include <initializer_list>
#include <algorithm>
#include <iostream>
#include <vector>

using namespace std;

const size_t insert_cost = 1;
const size_t delete_cost = 1;
const size_t replace_cost = 1;

size_t edit_distance(const string& A, const string& B)
{
    size_t NA = A.size();
    size_t NB = B.size();

    vector<size_t> M0(NB+1), M1(NB+1);

    for (size_t b = 0; b <= NB; ++b)
        M0[b] = b * delete_cost;

    for (size_t a = 1; a <= NA; ++a)
    {
        M1[0] = a * insert_cost;

        for (size_t b = 1; b <= NB; ++b)
        {
            size_t x = M0[b] + insert_cost;
            size_t y = M1[b-1] + delete_cost;
            size_t z = M0[b-1] + (A[a-1] == B[b-1] ? 0 : replace_cost);
            size_t y1 = min(x,y); M1[b] = min(y1,z);
        }

        swap(M0,M1);
    }

    return M0[NB];
}

