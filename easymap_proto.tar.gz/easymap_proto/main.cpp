#include <QApplication>
#include <iostream>
#include "mainwindow.h"
//#include "sda.h"

int main(int argc, char *argv[])
{

    QApplication app(argc, argv);
    MainWindow window;
    window.show();
    //window.oocva();

    QStringList arglist = app.arguments();
    if(arglist.size()>1)
    {window.close(); app.exit(0); }
    else
    return app.exec();
}
