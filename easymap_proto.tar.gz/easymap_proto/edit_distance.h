#include <string>
#include <algorithm>
//#include <vector>
size_t edit_distance(const std::string& A, const std::string& B);
