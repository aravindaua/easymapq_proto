static const char*oblasti_char[]={
(char*)"Crimea",
(char*)"Crimea",
(char*)"Crimea",
(char*)"Crimea",
(char*)"Crimea",
(char*)"Crimea",
(char*)"Crimea",
(char*)"Crimea",
(char*)"Crimea",
(char*)"Crimea",
(char*)"Crimea",
(char*)"Dnipropetrovs'k",
(char*)"Dnipropetrovs'k",
(char*)"Dnipropetrovs'k",
(char*)"Dnipropetrovs'k",
(char*)"Dnipropetrovs'k",
(char*)"Dnipropetrovs'k",
(char*)"Dnipropetrovs'k",
(char*)"Dnipropetrovs'k",
(char*)"Dnipropetrovs'k",
(char*)"Dnipropetrovs'k",
(char*)"Dnipropetrovs'k",
(char*)"Dnipropetrovs'k",
(char*)"Dnipropetrovs'k",
(char*)"Dnipropetrovs'k",
(char*)"Dnipropetrovs'k",
(char*)"Dnipropetrovs'k",
(char*)"Dnipropetrovs'k",
(char*)"Dnipropetrovs'k",
(char*)"Dnipropetrovs'k",
(char*)"Dnipropetrovs'k",
(char*)"Dnipropetrovs'k",
(char*)"Dnipropetrovs'k",
(char*)"Dnipropetrovs'k",
(char*)"Dnipropetrovs'k",
(char*)"Dnipropetrovs'k",
(char*)"Dnipropetrovs'k",
(char*)"Dnipropetrovs'k",
(char*)"Dnipropetrovs'k",
(char*)"Dnipropetrovs'k",
(char*)"Dnipropetrovs'k",
(char*)"Cherkasy",
(char*)"Cherkasy",
(char*)"Cherkasy",
(char*)"Cherkasy",
(char*)"Cherkasy",
(char*)"Cherkasy",
(char*)"Cherkasy",
(char*)"Cherkasy",
(char*)"Cherkasy",
(char*)"Cherkasy",
(char*)"Cherkasy",
(char*)"Cherkasy",
(char*)"Cherkasy",
(char*)"Cherkasy",
(char*)"Cherkasy",
(char*)"Cherkasy",
(char*)"Cherkasy",
(char*)"Cherkasy",
(char*)"Cherkasy",
(char*)"Cherkasy",
(char*)"Cherkasy",
(char*)"Cherkasy",
(char*)"Cherkasy",
(char*)"Chernihiv",
(char*)"Chernihiv",
(char*)"Chernihiv",
(char*)"Chernihiv",
(char*)"Chernihiv",
(char*)"Chernihiv",
(char*)"Chernihiv",
(char*)"Chernihiv",
(char*)"Chernihiv",
(char*)"Chernihiv",
(char*)"Chernihiv",
(char*)"Chernihiv",
(char*)"Chernihiv",
(char*)"Chernihiv",
(char*)"Chernihiv",
(char*)"Chernihiv",
(char*)"Chernihiv",
(char*)"Chernihiv",
(char*)"Chernihiv",
(char*)"Chernihiv",
(char*)"Chernihiv",
(char*)"Chernihiv",
(char*)"Chernihiv",
(char*)"Chernihiv",
(char*)"Chernihiv",//
(char*)"Chernivtsi",//
(char*)"Chernivtsi",//
(char*)"Chernivtsi",//
(char*)"Chernivtsi",//
(char*)"Chernivtsi",//
(char*)"Chernivtsi",//
(char*)"Chernivtsi",
(char*)"Chernivtsi",
(char*)"Chernivtsi",
(char*)"Chernivtsi",
(char*)"Chernivtsi",//
(char*)"Crimea",
(char*)"Crimea",
(char*)"Crimea",//
(char*)"Crimea",
(char*)"Crimea",
(char*)"Crimea",//
(char*)"Crimea",//
(char*)"Crimea",
(char*)"Crimea",
(char*)"Crimea",
(char*)"Crimea",
(char*)"Crimea",
(char*)"Dnipropetrovs'k",
(char*)"Dnipropetrovs'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Donets'k",
(char*)"Івано-Франківська",
(char*)"Івано-Франківська",
(char*)"Івано-Франківська",
(char*)"Івано-Франківська",
(char*)"Івано-Франківська",
(char*)"Івано-Франківська",
(char*)"Івано-Франківська",
(char*)"Івано-Франківська",
(char*)"Івано-Франківська",
(char*)"Івано-Франківська",
(char*)"Івано-Франківська",
(char*)"Івано-Франківська",
(char*)"Івано-Франківська",
(char*)"Івано-Франківська",
(char*)"Івано-Франківська",
(char*)"Івано-Франківська",
(char*)"Kharkiv",
(char*)"Kharkiv",
(char*)"Kharkiv",
(char*)"Kharkiv",
(char*)"Kharkiv",
(char*)"Kharkiv",
(char*)"Kharkiv",
(char*)"Kharkiv",
(char*)"Kharkiv",
(char*)"Kharkiv",
(char*)"Kharkiv",
(char*)"Kharkiv",
(char*)"Kharkiv",
(char*)"Kharkiv",
(char*)"Kharkiv",
(char*)"Kharkiv",
(char*)"Kharkiv",
(char*)"Kharkiv",
(char*)"Kharkiv",
(char*)"Kharkiv",
(char*)"Kharkiv",
(char*)"Kharkiv",
(char*)"Kharkiv",
(char*)"Kharkiv",
(char*)"Kharkiv",
(char*)"Kharkiv",
(char*)"Kharkiv",
(char*)"Kharkiv",
(char*)"Kharkiv",
(char*)"Kharkiv",
(char*)"Kharkiv",
(char*)"Kharkiv",
(char*)"Kherson",
(char*)"Kherson",
(char*)"Kherson",
(char*)"Kherson",
(char*)"Kherson",
(char*)"Kherson",
(char*)"Kherson",
(char*)"Kherson",
(char*)"Kherson",
(char*)"Kherson",
(char*)"Kherson",
(char*)"Kherson",
(char*)"Kherson",
(char*)"Kherson",
(char*)"Kherson",
(char*)"Kherson",
(char*)"Kherson",
(char*)"Kherson",
(char*)"Kherson",
(char*)"Kherson",
(char*)"Khmel'nyts'kyy",
(char*)"Khmel'nyts'kyy",
(char*)"Khmel'nyts'kyy",
(char*)"Khmel'nyts'kyy",
(char*)"Khmel'nyts'kyy",
(char*)"Khmel'nyts'kyy",
(char*)"Khmel'nyts'kyy",
(char*)"Khmel'nyts'kyy",
(char*)"Khmel'nyts'kyy",
(char*)"Khmel'nyts'kyy",
(char*)"Khmel'nyts'kyy",
(char*)"Khmel'nyts'kyy",
(char*)"Khmel'nyts'kyy",
(char*)"Khmel'nyts'kyy",
(char*)"Khmel'nyts'kyy",
(char*)"Khmel'nyts'kyy",
(char*)"Khmel'nyts'kyy",
(char*)"Khmel'nyts'kyy",
(char*)"Khmel'nyts'kyy",
(char*)"Khmel'nyts'kyy",
(char*)"Khmel'nyts'kyy",
(char*)"Khmel'nyts'kyy",
(char*)"Khmel'nyts'kyy",
(char*)"Київ, місто",
(char*)"Київ, місто",
(char*)"Київ, місто",
(char*)"Київ, місто",
(char*)"Київ, місто",
(char*)"Київ, місто",
(char*)"Київ, місто",
(char*)"Київ, місто",
(char*)"Київ, місто",
(char*)"Київ, місто",
(char*)"Київська",
(char*)"Київська",
(char*)"Київська",
(char*)"Київська",
(char*)"Київська",
(char*)"Київська",
(char*)"Київська",
(char*)"Київська",
(char*)"Київська",
(char*)"Київська",
(char*)"Київська",
(char*)"Київська",
(char*)"Київська",
(char*)"Київська",
(char*)"Київська",
(char*)"Київська",
(char*)"Київська",
(char*)"Київська",
(char*)"Київська",
(char*)"Київська",
(char*)"Київська",
(char*)"Київська",
(char*)"Київська",
(char*)"Київська",
(char*)"Київська",
(char*)"Київська",
(char*)"Київська",
(char*)"Київська",
(char*)"Київська",
(char*)"Київська",
(char*)"Kirovohrad",
(char*)"Kirovohrad",
(char*)"Kirovohrad",
(char*)"Kirovohrad",
(char*)"Kirovohrad",
(char*)"Kirovohrad",
(char*)"Kirovohrad",
(char*)"Kirovohrad",
(char*)"Kirovohrad",
(char*)"Kirovohrad",
(char*)"Kirovohrad",
(char*)"Kirovohrad",
(char*)"Kirovohrad",
(char*)"Kirovohrad",
(char*)"Kirovohrad",
(char*)"Kirovohrad",
(char*)"Kirovohrad",
(char*)"Kirovohrad",
(char*)"Kirovohrad",
(char*)"Kirovohrad",
(char*)"Kirovohrad",
(char*)"L'viv",
(char*)"L'viv",
(char*)"L'viv",
(char*)"L'viv",
(char*)"L'viv",
(char*)"L'viv",
(char*)"L'viv",
(char*)"L'viv",
(char*)"L'viv",
(char*)"L'viv",
(char*)"L'viv",
(char*)"L'viv",
(char*)"L'viv",
(char*)"L'viv",
(char*)"L'viv",
(char*)"L'viv",
(char*)"L'viv",
(char*)"L'viv",
(char*)"L'viv",
(char*)"L'viv",
(char*)"L'viv",
(char*)"L'viv",
(char*)"L'viv",
(char*)"L'viv",
(char*)"L'viv",
(char*)"Luhans'k",
(char*)"Luhans'k",
(char*)"Luhans'k",
(char*)"Luhans'k",
(char*)"Luhans'k",
(char*)"Luhans'k",
(char*)"Luhans'k",
(char*)"Luhans'k",
(char*)"Luhans'k",
(char*)"Luhans'k",
(char*)"Luhans'k",
(char*)"Luhans'k",
(char*)"Luhans'k",
(char*)"Luhans'k",
(char*)"Luhans'k",
(char*)"Luhans'k",
(char*)"Luhans'k",
(char*)"Luhans'k",
(char*)"Luhans'k",
(char*)"Luhans'k",
(char*)"Luhans'k",
(char*)"Luhans'k",
(char*)"Luhans'k",
(char*)"Luhans'k",
(char*)"Luhans'k",
(char*)"Luhans'k",
(char*)"Luhans'k",
(char*)"Luhans'k",
(char*)"Luhans'k",
(char*)"Luhans'k",
(char*)"Luhans'k",
(char*)"Luhans'k",
(char*)"Mykolayiv",
(char*)"Mykolayiv",
(char*)"Mykolayiv",
(char*)"Mykolayiv",
(char*)"Mykolayiv",
(char*)"Mykolayiv",
(char*)"Mykolayiv",
(char*)"Mykolayiv",
(char*)"Mykolayiv",
(char*)"Mykolayiv",
(char*)"Mykolayiv",
(char*)"Mykolayiv",
(char*)"Mykolayiv",
(char*)"Mykolayiv",
(char*)"Mykolayiv",
(char*)"Mykolayiv",
(char*)"Mykolayiv",
(char*)"Mykolayiv",
(char*)"Mykolayiv",
(char*)"Mykolayiv",
(char*)"Mykolayiv",
(char*)"Mykolayiv",
(char*)"Одеська",
(char*)"Одеська",
(char*)"Одеська",
(char*)"Одеська",
(char*)"Одеська",
(char*)"Одеська",
(char*)"Одеська",
(char*)"Одеська",
(char*)"Одеська",
(char*)"Одеська",
(char*)"Одеська",
(char*)"Одеська",
(char*)"Одеська",
(char*)"Одеська",
(char*)"Одеська",
(char*)"Одеська",
(char*)"Одеська",
(char*)"Одеська",
(char*)"Одеська",
(char*)"Одеська",
(char*)"Одеська",
(char*)"Одеська",
(char*)"Одеська",
(char*)"Одеська",
(char*)"Одеська",
(char*)"Одеська",
(char*)"Одеська",
(char*)"Одеська",
(char*)"Одеська",
(char*)"Poltava",
(char*)"Poltava",
(char*)"Poltava",
(char*)"Poltava",
(char*)"Poltava",
(char*)"Poltava",
(char*)"Poltava",
(char*)"Poltava",
(char*)"Poltava",
(char*)"Poltava",
(char*)"Poltava",
(char*)"Poltava",
(char*)"Poltava",
(char*)"Poltava",
(char*)"Poltava",
(char*)"Poltava",
(char*)"Poltava",
(char*)"Poltava",
(char*)"Poltava",
(char*)"Poltava",
(char*)"Poltava",
(char*)"Poltava",
(char*)"Poltava",
(char*)"Poltava",
(char*)"Poltava",
(char*)"Poltava",
(char*)"Poltava",
(char*)"Poltava",
(char*)"Poltava",
(char*)"Rivne",
(char*)"Rivne",
(char*)"Rivne",
(char*)"Rivne",
(char*)"Rivne",
(char*)"Rivne",
(char*)"Rivne",
(char*)"Rivne",
(char*)"Rivne",
(char*)"Rivne",
(char*)"Rivne",
(char*)"Rivne",
(char*)"Rivne",
(char*)"Rivne",
(char*)"Rivne",
(char*)"Rivne",
(char*)"Rivne",
(char*)"Rivne",
(char*)"Sevastopol'",
(char*)"Sevastopol'",
(char*)"Sevastopol'",
(char*)"Sevastopol'",
(char*)"Sumy",
(char*)"Sumy",
(char*)"Sumy",
(char*)"Sumy",
(char*)"Sumy",
(char*)"Sumy",
(char*)"Sumy",
(char*)"Sumy",
(char*)"Sumy",
(char*)"Sumy",
(char*)"Sumy",
(char*)"Sumy",
(char*)"Sumy",
(char*)"Sumy",
(char*)"Sumy",
(char*)"Sumy",
(char*)"Sumy",
(char*)"Sumy",
(char*)"Sumy",
(char*)"Sumy",
(char*)"Sumy",
(char*)"Sumy",
(char*)"Sumy",
(char*)"Ternopil'",
(char*)"Ternopil'",
(char*)"Ternopil'",
(char*)"Ternopil'",
(char*)"Ternopil'",
(char*)"Ternopil'",
(char*)"Ternopil'",
(char*)"Ternopil'",
(char*)"Ternopil'",
(char*)"Ternopil'",
(char*)"Ternopil'",
(char*)"Ternopil'",
(char*)"Ternopil'",
(char*)"Ternopil'",
(char*)"Ternopil'",
(char*)"Ternopil'",
(char*)"Ternopil'",
(char*)"Ternopil'",
(char*)"Закарпаття",
(char*)"Закарпаття",
(char*)"Закарпаття",
(char*)"Закарпаття",
(char*)"Закарпаття",
(char*)"Закарпаття",
(char*)"Закарпаття",
(char*)"Закарпаття",
(char*)"Закарпаття",
(char*)"Закарпаття",
(char*)"Закарпаття",
(char*)"Закарпаття",
(char*)"Закарпаття",
(char*)"Закарпаття",
(char*)"Закарпаття",
(char*)"Vinnytsya",
(char*)"Vinnytsya",
(char*)"Vinnytsya",
(char*)"Vinnytsya",
(char*)"Vinnytsya",
(char*)"Vinnytsya",
(char*)"Vinnytsya",
(char*)"Vinnytsya",
(char*)"Vinnytsya",
(char*)"Vinnytsya",
(char*)"Vinnytsya",
(char*)"Vinnytsya",
(char*)"Vinnytsya",
(char*)"Vinnytsya",
(char*)"Vinnytsya",
(char*)"Vinnytsya",
(char*)"Vinnytsya",
(char*)"Vinnytsya",
(char*)"Vinnytsya",
(char*)"Vinnytsya",
(char*)"Vinnytsya",
(char*)"Vinnytsya",
(char*)"Vinnytsya",
(char*)"Vinnytsya",
(char*)"Vinnytsya",
(char*)"Vinnytsya",
(char*)"Vinnytsya",
(char*)"Vinnytsya",
(char*)"Vinnytsya",
(char*)"Volyn",
(char*)"Volyn",
(char*)"Volyn",
(char*)"Volyn",
(char*)"Volyn",
(char*)"Volyn",
(char*)"Volyn",
(char*)"Volyn",
(char*)"Volyn",
(char*)"Volyn",
(char*)"Volyn",
(char*)"Volyn",
(char*)"Volyn",
(char*)"Volyn",
(char*)"Volyn",
(char*)"Volyn",
(char*)"Volyn",
(char*)"Volyn",
(char*)"Volyn",
(char*)"Zaporizhzhya",
(char*)"Zaporizhzhya",
(char*)"Zaporizhzhya",
(char*)"Zaporizhzhya",
(char*)"Zaporizhzhya",
(char*)"Zaporizhzhya",
(char*)"Zaporizhzhya",
(char*)"Zaporizhzhya",
(char*)"Zaporizhzhya",
(char*)"Zaporizhzhya",
(char*)"Zaporizhzhya",
(char*)"Zaporizhzhya",
(char*)"Zaporizhzhya",
(char*)"Zaporizhzhya",
(char*)"Zaporizhzhya",
(char*)"Zaporizhzhya",
(char*)"Zaporizhzhya",
(char*)"Zaporizhzhya",
(char*)"Zaporizhzhya",
(char*)"Zaporizhzhya",
(char*)"Zaporizhzhya",
(char*)"Zaporizhzhya",
(char*)"Zaporizhzhya",
(char*)"Zaporizhzhya",
(char*)"Zaporizhzhya",
(char*)"Zhytomyr",
(char*)"Zhytomyr",
(char*)"Zhytomyr",
(char*)"Zhytomyr",
(char*)"Zhytomyr",
(char*)"Zhytomyr",
(char*)"Zhytomyr",
(char*)"Zhytomyr",
(char*)"Zhytomyr",
(char*)"Zhytomyr",
(char*)"Zhytomyr",
(char*)"Zhytomyr",
(char*)"Zhytomyr",
(char*)"Zhytomyr",
(char*)"Zhytomyr",
(char*)"Zhytomyr",
(char*)"Zhytomyr",
(char*)"Zhytomyr",
(char*)"Zhytomyr",
(char*)"Zhytomyr",
(char*)"Zhytomyr",
(char*)"Zhytomyr",
(char*)"Zhytomyr",
(char*)"Zhytomyr",
(char*)"Zhytomyr",
(char*)"Zhytomyr",
(char*)"Zhytomyr"
};
static const char*rayony_char[]={
(char*)"Krasnoperekops'kyi",
(char*)"Lenins'kyi",
(char*)"Nyzhn'ohirs'kyi",
(char*)"Pervomais'kyi",
(char*)"Rozdol'nens'kyi",
(char*)"Saks'ka",
(char*)"Saks'kyi",
(char*)"Simferopol's'ka",
(char*)"Simferopol's'kyi",
(char*)"Soviets'kyi",
(char*)"Sudats'ka",
(char*)"Apostolivs'kyi",
(char*)"Dniprodzerzhyns'ka",
(char*)"Dnipropetrovs'ka",
(char*)"Dnipropetrovs'kyi",
(char*)"Iurïvs'kyi",
(char*)"Krynychans'kyi",
(char*)"Kryvoriz'kyi",
(char*)"KryvyiRig",
(char*)"Mahdalynivs'kyi",
(char*)"Marhanets'ka",
(char*)"Mezhivs'kyi",
(char*)"Nikopol's'ka",
(char*)"Nikopol's'kyi",
(char*)"Novomoskovs'ka",
(char*)"Novomoskovs'kyi",
(char*)"Ordzhonikidzevs'ka",
(char*)"Pavlograd",
(char*)"Pavlohrads'kyi",
(char*)"Petropavlivs'kyi",
(char*)"Petrykivs'kyi",
(char*)"Piatykhats'kyi",
(char*)"Pokrovs'kyi",
(char*)"Shyrokivs'kyi",
(char*)"Sofi‹vs'kyi",
(char*)"Solonians'kyi",
(char*)"Synel'nykivs'ka",
(char*)"Synel'nykivs'kyi",
(char*)"Tomakivs'kyi",
(char*)"Tsarychans'kyi",
(char*)"Vasyl'kivs'kyi",
(char*)"Cherkas'ka",
(char*)"Cherkas'kyi",
(char*)"Chornobaivs'kyi",
(char*)"Chyhyryns'kyi",
(char*)"Drabivs'kyi",
(char*)"Horodyshchens'kyi",
(char*)"Kamians'kyi",
(char*)"Kanivs'ka",
(char*)"Kanivs'kyi",
(char*)"Katerynopil's'kyi",
(char*)"Khrystynivs'kyi",
(char*)"Korsun'-Shevchenkivs'kyi",
(char*)"Lysians'kyi",
(char*)"Man'kivs'kyi",
(char*)"Monastyryshchens'kyi",
(char*)"Shpolians'kyi",
(char*)"Smilians'kyi",
(char*)"Tal'nivs'kyi",
(char*)"Umans'ka",
(char*)"Umans'kyi",
(char*)"Zhashkivs'kyi",
(char*)"Zolotonis'kyi",
(char*)"Zvenyhorods'kyi",
(char*)"Bakhmats'kyi",
(char*)"Bobrovyts'kyi",
(char*)"Borznians'kyi",
(char*)"Chernihivs'ka",
(char*)"Chernihivs'kyi",
(char*)"Horodnians'kyi",
(char*)"Ichnians'kyi",
(char*)"Koriukivs'kyi",
(char*)"Korops'kyi",
(char*)"Kozelets'kyi",
(char*)"Kulykivs'kyi",
(char*)"Mens'kyi",
(char*)"Nizhyns'ka",
(char*)"Nizhyns'kyi",
(char*)"Nosivs'kyi",
(char*)"Novhorod-Sivers'kyi",
(char*)"Pryluts'ka",
(char*)"Pryluts'kyi",
(char*)"Ripkyns'kyi",
(char*)"Semenivs'kyi",
(char*)"Shchors'kyi",
(char*)"Sosnyts'kyi",
(char*)"Sribnians'kyi",
(char*)"Talala‹vs'kyi",
(char*)"Varvyns'kyi",
(char*)"Chernivets'ka",
(char*)"Hlybots'kyi",
(char*)"Kel'menets'kyi",
(char*)"Khotyns'kyi",
(char*)"Kitsmans'kyi",
(char*)"Novoselits'kyi",
(char*)"Putyl's'kyi",
(char*)"Sokyrians'kyi",
(char*)"Storozhynets'kyi",
(char*)"Vyzhnyts'kyi",
(char*)"Zastavnets'kyi",
(char*)"Alushtyns'ka",
(char*)"Bakhchysarais'kyi",
(char*)"Bilohirs'kyi",
(char*)"Chornomors'kyi",
(char*)"Dzhankois'ka",
(char*)"Dzhankois'kyi",
(char*)"Feodosiis'ka",
(char*)"Ialtyns'ka",
(char*)"Ievpatoriis'ka",
(char*)"Kerchens'ka",
(char*)"Kirovs'kyi",
(char*)"Krasnohvardiis'kyi",
(char*)"Verkhn'odniprovs'kyi",
(char*)"Zhovtovods'ka",
(char*)"Amvrosi‹vs'kyi",
(char*)"Artemivs'ka",
(char*)"Artemivs'kyi",
(char*)"Dobropil's'ka",
(char*)"Dobropil's'kyi",
(char*)"Donets'ka",
(char*)"Dzerzhyns'ka",
(char*)"Horlivs'ka",
(char*)"Iasynuvats'ka",
(char*)"Iasynuvats'kyi",
(char*)"Ienakiievs'ka",
(char*)"Khartsyz'ka",
(char*)"Kirovs'ka",
(char*)"Kostiantynivs'ka",
(char*)"Kostiantynivs'kyi",
(char*)"Kramators'ka",
(char*)"Krasnoarmiis'ka",
(char*)"Krasnoarmiis'kyi",
(char*)"Krasnolymans'ka",
(char*)"Krasnolymans'kyi",
(char*)"Maki‹vs'ka",
(char*)"Mar‹ns'kyi",
(char*)"Mariupol's'ka",
(char*)"n.a.(181)",
(char*)"n.a.(319)",
(char*)"n.a.(384)",
(char*)"n.a.(394)",
(char*)"n.a.(488)",
(char*)"n.a.(493)",
(char*)"n.a.(511)",
(char*)"Novoazovs'kyi",
(char*)"Novohrodivs'ka",
(char*)"Oleksandrivs'kyi",
(char*)"Pershotravnevyi",
(char*)"Selydovs'ka",
(char*)"Shakhtars'ka",
(char*)"Shakhtars'kyi",
(char*)"Slovians'ka",
(char*)"Slovians'kyi",
(char*)"Snizhnens'ka",
(char*)"Starobeshivs'kyi",
(char*)"Tel'manivs'kyi",
(char*)"Torez'ka",
(char*)"Velykonovosilkivs'kyi",
(char*)"Volnovas'kyi",
(char*)"Volodars'kyi",
(char*)"Vuhledars'ka",
(char*)"Zhdanivs'ka",
(char*)"Bohorodchans'kyi",
(char*)"Dolyns'kyi",
(char*)"Halyts'kyi",
(char*)"Horodenkivs'kyi",
(char*)"Iaremchans'ka",
(char*)"Івано-Франківський",
(char*)"Kalus'kyi",
(char*)"Kolomyis'kyi",
(char*)"Kosivs'kyi",
(char*)"Nadvirnians'kyi",
(char*)"Rohatyns'kyi",
(char*)"Rozhniativs'kyi",
(char*)"Sniatyns'kyi",
(char*)"Tlumats'kyi",
(char*)"Tysmenyts'kyi",
(char*)"Verkhovyns'kyi",
(char*)"Balakliis'kyi",
(char*)"Barvinkivs'kyi",
(char*)"Blyzniukivs'kyi",
(char*)"Bohodukhivs'kyi",
(char*)"Borivs'kyi",
(char*)"Chuhu‹vs'ka",
(char*)"Chuhu‹vs'kyi",
(char*)"Derhachivs'kyi",
(char*)"Dvorichans'kyi",
(char*)"Iziums'ka",
(char*)"Iziums'kyi",
(char*)"Kehychivs'kyi",
(char*)"Kharkivs'ka",
(char*)"Kharkivs'kyi",
(char*)"Krasnohrads'kyi",
(char*)"Krasnokuts'kyi",
(char*)"Kupians'ka",
(char*)"Kupians'kyi",
(char*)"Lozivs'ka",
(char*)"Lozivs'kyi",
(char*)"n.a.(180)",
(char*)"Novovodolaz'kyi",
(char*)"Pecheniz'kyi",
(char*)"Pervomais'kyi",
(char*)"Sakhnovshchyns'kyi",
(char*)"Shevchenkivs'kyi",
(char*)"Valkivs'kyi",
(char*)"Velykoburluts'kyi",
(char*)"Vovchans'kyi",
(char*)"Zachepylivs'kyi",
(char*)"Zmiïvs'kyi",
(char*)"Zolochivs'kyi",
(char*)"Beryslavs'kyi",
(char*)"Bilozers'kyi",
(char*)"Chaplyns'kyi",
(char*)"Heniches'kyi",
(char*)"Holoprystans'kyi",
(char*)"Hornosta‹vs'kyi",
(char*)"Ivanivs'kyi",
(char*)"Kakhovs'kyi",
(char*)"Kalanchats'kyi",
(char*)"Khersons'ka",
(char*)"Novokahovs'ka",
(char*)"Novotro‹ts'kyi",
(char*)"Novovorontsovs'kyi",
(char*)"Nyzhn'osirohoz'kyi",
(char*)"Skadovs'kyi",
(char*)"Tsiurupyns'kyi",
(char*)"Velykolepetys'kyi",
(char*)"Velykooleksandrivs'kyi",
(char*)"Verkhn'orohachyts'kyi",
(char*)"Vysokopil's'kyi",
(char*)"Bilohirs'kyi",
(char*)"Chemerovets'kyi",
(char*)"Derazhnians'kyi",
(char*)"Dunaievets'kyi",
(char*)"Horodots'kyi",
(char*)"Iarmolynets'kyi",
(char*)"Iziaslavs'kyi",
(char*)"Kamianets'-Podil's'ka",
(char*)"Kamianets'-Podil's'kyi",
(char*)"Khmel'nyts'ka",
(char*)"Khmel'nyts'kyi",
(char*)"Krasylivs'kyi",
(char*)"Letychivs'kyi",
(char*)"Novoushyts'kyi",
(char*)"Polons'kyi",
(char*)"Shepetivs'ka",
(char*)"Shepetivs'kyi",
(char*)"Slavuts'kyi",
(char*)"Starokostiantynivs'kyi",
(char*)"Starosyniavs'kyi",
(char*)"Teofipol's'kyi",
(char*)"Vin'kovets'kyi",
(char*)"Volochys'kyi",
(char*)"Darnyts'kyi",
(char*)"Desnians'kyi",
(char*)"Dniprovs'kyi",
(char*)"Holosiïvs'kyi",
(char*)"Obolons'kyi",
(char*)"Pechers'kyi",
(char*)"Podil's'kyi",
(char*)"Shevchenkivs'kyi",
(char*)"Solomians'kyi",
(char*)"Sviatoshyns'kyi",
(char*)"Baryshivs'kyi",
(char*)"Bilotserkivs'ka",
(char*)"Bilotserkivs'kyi",
(char*)"Bohuslavs'kyi",
(char*)"Borodians'kyi",
(char*)"Boryspil's'ka",
(char*)"Brovars'ka",
(char*)"Brovars'kyi",
(char*)"Fastivs'ka",
(char*)"Fastivs'kyi",
(char*)"Iahotyns'kyi",
(char*)"Irpins'ka",
(char*)"Ivankivs'kyi",
(char*)"Kaharlyts'kyi",
(char*)"Kyievo-Sviatoshyns'kyi",
(char*)"Makarivs'kyi",
(char*)"Myronivs'kyi",
(char*)"Obukhivs'kyi",
(char*)"Pereiaslav-Khmel'nyts'ka",
(char*)"Pereiaslav-Khmel'nyts'kyi",
(char*)"Polis'kyi",
(char*)"Rokytnians'kyi",
(char*)"Skvyrs'kyi",
(char*)"Stavyshchens'kyi",
(char*)"Tarashchans'kyi",
(char*)"Tetiïvs'kyi",
(char*)"Vasyl'kivs'kyi",
(char*)"Volodars'kyi",
(char*)"Vyshhorods'kyi",
(char*)"Zgurivs'kyi",
(char*)"Bobrynets'kyi",
(char*)"Dobrovelychkivs'kyi",
(char*)"Dolyns'kyi",
(char*)"Haivorons'kyi",
(char*)"Holovanivs'kyi",
(char*)"Kirovohrads'kyi",
(char*)"Kompani‹vs'kyi",
(char*)"Malovyskivs'kyi",
(char*)"Novhorodkivs'kyi",
(char*)"Novoarkhanhel's'kyi",
(char*)"Novomyrhorods'kyi",
(char*)"Novoukra‹ns'kyi",
(char*)"Oleksandriis'kyi",
(char*)"Oleksandrivs'kyi",
(char*)"Onufri‹vs'kyi",
(char*)"Petrivs'kyi",
(char*)"Svitlovods'kyi",
(char*)"Ul'ianovs'kyi",
(char*)"Ustynivs'kyi",
(char*)"Vil'shans'kyi",
(char*)"Znamians'kyi",
(char*)"Brodivs'kyi",
(char*)"Bus'kyi",
(char*)"Chervonohrads'ka",
(char*)"Drohobyts'ka",
(char*)"Drohobyts'kyi",
(char*)"Horodots'kyi",
(char*)"Iavorivs'kyi",
(char*)"Kamianka-Buz'kyi",
(char*)"L'vivs'ka",
(char*)"Mostys'kyi",
(char*)"Mykola‹vs'kyi",
(char*)"Peremyshlians'kyi",
(char*)"Pustomytivs'kyi",
(char*)"Radekhivs'kyi",
(char*)"Sambirs'ka",
(char*)"Sambirs'kyi",
(char*)"Skolivs'kyi",
(char*)"Sokal's'kyi",
(char*)"Starosambirs'kyi",
(char*)"Stryis'ka",
(char*)"Stryis'kyi",
(char*)"Turkivs'kyi",
(char*)"Zhovkivs'kyi",
(char*)"Zhydachivs'kyi",
(char*)"Zolochivs'kyi",
(char*)"Alchevs'ka",
(char*)"Antratsitivs'ka",
(char*)"Antratsytivs'kyi",
(char*)"Bilokurakyns'kyi",
(char*)"Bilovods'kyi",
(char*)"Briankivs'ka",
(char*)"Kirovs'ka",
(char*)"Krasnodons'ka",
(char*)"Krasnodons'kyi",
(char*)"Krasnoluts'ka",
(char*)"Kremins'kyi",
(char*)"Luhans'ka",
(char*)"Lutuhyns'kyi",
(char*)"Lysychans'ka",
(char*)"Markivs'kyi",
(char*)"Milovs'kyi",
(char*)"n.a.(182)",
(char*)"Novoaidars'kyi",
(char*)"Novopskovs'kyi",
(char*)"Pereval's'kyi",
(char*)"Popasnians'kyi",
(char*)"Roven'kivs'ka",
(char*)"Rubezhans'ka",
(char*)"Sieverodonets'ka",
(char*)"Slovianoserbs'kyi",
(char*)"Stakhanivs'ka",
(char*)"Stanychno-Luhans'kyi",
(char*)"Starobil's'kyi",
(char*)"Svativs'kyi",
(char*)"Sverdlovs'ka",
(char*)"Sverdlovs'kyi",
(char*)"Tro‹ts'kyi",
(char*)"Arbuzyns'kyi",
(char*)"Bashtans'kyi",
(char*)"Berezans'kyi",
(char*)"Bereznehuvats'kyi",
(char*)"Brats'kyi",
(char*)"Domanivs'kyi",
(char*)"Ielanets'kyi",
(char*)"Kazanetskyi",
(char*)"Kryvoozers'kyi",
(char*)"Mykola‹vs'ka",
(char*)"Mykola‹vs'kyi",
(char*)"Novobuz'kyi",
(char*)"Novoodes'kyi",
(char*)"Ochakivs'kyi",
(char*)"Pervomais'ka",
(char*)"Pervomais'kyi",
(char*)"Snihurivs'kyi",
(char*)"Veselynivs'kyi",
(char*)"Voznesens'ka",
(char*)"Voznesens'kyi",
(char*)"Vradi‹vs'kyi",
(char*)"Zhovtnevyi",
(char*)"Anan'‹vs'kyi",
(char*)"Artsyz'kyi",
(char*)"Balts'kyi",
(char*)"Berezivs'kyi",
(char*)"Bilhorod-Dnistrovs'ka",
(char*)"Bilhorod-Dnistrovs'kyi",
(char*)"Bilia‹vs'kyi",
(char*)"Bolhrads'kyi",
(char*)"Frunzivs'kyi",
(char*)"Ivanivs'kyi",
(char*)"Izma‹l's'ka",
(char*)"Kiliis'kyi",
(char*)"Kodyms'kyi",
(char*)"Kominternivs'kyi",
(char*)"Kotovs'ka",
(char*)"Kotovs'kyi",
(char*)"Krasnooknians'kyi",
(char*)"Liubashivs'kyi",
(char*)"Mykola‹vs'kyi",
(char*)"Odes'ka",
(char*)"Ovidiopol's'kyi",
(char*)"Reniis'kyi",
(char*)"Rozdil'nias'kyi",
(char*)"Sarats'kyi",
(char*)"Savrans'kyi",
(char*)"Shyria‹vs'kyi",
(char*)"Tarutyns'kyi",
(char*)"Tatarbunars'kyi",
(char*)"Velykomykhailivs'kyi",
(char*)"Chornukhyns'kyi",
(char*)"Chutivs'kyi",
(char*)"Dykans'kyi",
(char*)"Hadiats'kyi",
(char*)"Hlobyns'kyi",
(char*)"Hrebinkivs'kyi",
(char*)"Karlivs'kyi",
(char*)"Khorol's'kyi",
(char*)"Kobeliats'kyi",
(char*)"Komsomol's'ka",
(char*)"Kotelevs'kyi",
(char*)"Kozel'shchyns'kyi",
(char*)"Kremenchuts'ka",
(char*)"Kremenchuts'kyi",
(char*)"Lokhvyts'kyi",
(char*)"Lubens'ka",
(char*)"Lubens'kyi",
(char*)"Mashivs'kyi",
(char*)"Myrhorods'kyi",
(char*)"Novosanzhars'kyi",
(char*)"Orzhyts'kyi",
(char*)"Poltavs'ka",
(char*)"Poltavs'kyi",
(char*)"Pyriatyns'kyi",
(char*)"Reshetylivs'kyi",
(char*)"Semenivs'kyi",
(char*)"Shyshats'kyi",
(char*)"Velykobahachans'kyi",
(char*)"Zin'kivs'kyi",
(char*)"Bereznivs'kyi",
(char*)"Demydiv's'kyi",
(char*)"Dubens'kyi",
(char*)"Dubnivs'ka",
(char*)"Dubrovyts'kyi",
(char*)"Hoshchans'kyi",
(char*)"Korets'kyi",
(char*)"Kostopil's'kyi",
(char*)"Mlynivs'kyi",
(char*)"Ostroz'kyi",
(char*)"Radyvylivs'kyi",
(char*)"Rivnens'ka",
(char*)"Rivnens'kyi",
(char*)"Rokytnivs'kyi",
(char*)"Sarnens'kyi",
(char*)"Volodymyrets'kyi",
(char*)"Zarichnens'kyi",
(char*)"Zdolbunivs'kyi",
(char*)"Balaklavs'kyi",
(char*)"Haharins'kyi",
(char*)"Lenins'kyi",
(char*)"Nakhimovs'kyi",
(char*)"Bilopils'kyi",
(char*)"Buryns'kyi",
(char*)"Hlukhivs'kyi",
(char*)"Iampil's'kyi",
(char*)"Konotops'ka",
(char*)"Konotops'kyi",
(char*)"Krasnopil's'kyi",
(char*)"Krolevets'kyi",
(char*)"Lebedyns'kyi",
(char*)"Lypovodolyns'kyi",
(char*)"Nedryhailivs'kyi",
(char*)"Okhtyrs'ka",
(char*)"Okhtyrs'kyi",
(char*)"Putyvl's'kyi",
(char*)"Romens'ka",
(char*)"Romens'kyi",
(char*)"Seredyno-Buds'kyi",
(char*)"Shostkins'ka",
(char*)"Shostkins'kyi",
(char*)"Sums'ka",
(char*)"Sums'kyi",
(char*)"Trostianets'kyi",
(char*)"Velykopysarivs'kyi",
(char*)"Berezhans'kyi",
(char*)"Borshchivs'kyi",
(char*)"Buchats'kyi",
(char*)"Chortkivs'kyi",
(char*)"Husiatyns'kyi",
(char*)"Kozivs'kyi",
(char*)"Kremenets'kyi",
(char*)"Lanovets'kyi",
(char*)"Monastyrys'kyi",
(char*)"Pidhaiets'kyi",
(char*)"Pidvolochys'kyi",
(char*)"Shums'kyi",
(char*)"Terebovlians'kyi",
(char*)"Ternopil's'ka",
(char*)"Ternopil's'kyi",
(char*)"Zalishchyts'kyi",
(char*)"Zbaraz'kyi",
(char*)"Zborivs'kyi",
(char*)"Berehivs'kyi",
(char*)"Irshavs'kyi",
(char*)"Khusts'kyi",
(char*)"Mizhhirs'kyi",
(char*)"Mukachivs'ka",
(char*)"Mukachivs'kyi",
(char*)"Perechyns'kyi",
(char*)"Rakhivs'kyi",
(char*)"Svaliavs'kyi",
(char*)"Tiachivs'kyi",
(char*)"Uzhhorods'ka",
(char*)"Uzhhorods'kyi",
(char*)"Velykobereznians'kyi",
(char*)"Volovets'kyi",
(char*)"Vynohradivs'kyi",
(char*)"Bars'kyi",
(char*)"Bershads'kyi",
(char*)"Chechel'nyts'kyi",
(char*)"Iampil's'kyi",
(char*)"Illinets'kyi",
(char*)"Kalynivs'kyi",
(char*)"Khmil'nyts'kyi",
(char*)"Koziatyns'kyi",
(char*)"Kryzhopil's'kyi",
(char*)"Ladyzhyns'ka",
(char*)"Lityns'kyi",
(char*)"Lypovets'kyi",
(char*)"Mohyliv-Podil's'ka",
(char*)"Mohyliv-Podil's'kyi",
(char*)"Murovano-Kurylovets'kyi",
(char*)"Nemyrivs'kyi",
(char*)"Orativs'kyi",
(char*)"Pishchans'kyi",
(char*)"Pohrebyshchens'kyi",
(char*)"Sharhorods'kyi",
(char*)"Teplyts'kyi",
(char*)"Tomashpil's'kyi",
(char*)"Trostianets'kyi",
(char*)"Tul'chyns'kyi",
(char*)"Tyvrivs'kyi",
(char*)"Vinnyts'ka",
(char*)"Vinnyts'kyi",
(char*)"Zhmeryns'ka",
(char*)"Zhmeryns'kyi",
(char*)"Horokhivs'kyi",
(char*)"Ivanychivs'kyi",
(char*)"Kamin'-Kashyrs'kyi",
(char*)"Kivertsivs'kyi",
(char*)"Kovel's'ka",
(char*)"Kovel's'kyi",
(char*)"Liubeshivs'kyi",
(char*)"Liuboml's'ky",
(char*)"Lokachyns'kyi",
(char*)"Luts'ka",
(char*)"Luts'kyi",
(char*)"Manevyts'kyi",
(char*)"Novovolyns'ka",
(char*)"Ratnivs'kyi",
(char*)"Rozhyshchens'kyi",
(char*)"Shats'kyi",
(char*)"Starovyzhivs'kyi",
(char*)"Turiis'kyi",
(char*)"Volodymyr-Volyns'kyi",
(char*)"Berdians'ka",
(char*)"Berdians'kyi",
(char*)"Chernihivs'kyi",
(char*)"Enerhodars'ka",
(char*)"Huliaipil's'kyi",
(char*)"Iakymivs'kyi",
(char*)"Kamians'ko-Dniprovs'kyi",
(char*)"Kuibyshevs'kyi",
(char*)"Melitopol's'ka",
(char*)"Melitopol's'kyi",
(char*)"Mykhailivs'kyi",
(char*)"Novomykola‹vs'kyi",
(char*)"Orikhivs'kyi",
(char*)"Polohivs'kyi",
(char*)"Pryazovs'kyi",
(char*)"Prymors'kyi",
(char*)"Rozivs'kyi",
(char*)"Tokmats'ka",
(char*)"Tokmats'kyi",
(char*)"Vasylivs'kyi",
(char*)"Velykobilozers'kyi",
(char*)"Veselivs'kyi",
(char*)"Vil'nians'kyi",
(char*)"Zaporiz'ka",
(char*)"Zaporiz'kyi",
(char*)"Andrushivs'kyi",
(char*)"Baranivs'kyi",
(char*)"Berdychivs'ka",
(char*)"Berdychivs'kyi",
(char*)"Brusylivs'kyi",
(char*)"Cherniakhivs'kyi",
(char*)"Chervonoarmiis'kyi",
(char*)"Chudnivs'kyi",
(char*)"Iemil'chyns'kyi",
(char*)"Korostens'ka",
(char*)"Korostens'kyi",
(char*)"Korostyshivs'kyi",
(char*)"Liubars'kyi",
(char*)"Luhyns'kyi",
(char*)"Malyns'kyi",
(char*)"Narodyts'kyi",
(char*)"Novohrad-Volyns'ka",
(char*)"Novohrad-Volyns'kyi",
(char*)"Olevs'kyi",
(char*)"Ovruts'kyi",
(char*)"Popil'nians'kyi",
(char*)"Radomyshl's'kyi",
(char*)"Romanivs'kyi",
(char*)"Ruzhyns'kyi",
(char*)"Volodars'ko-Volyns'kyi",
(char*)"Zhytomyrs'ka",
(char*)"Zhytomyrs'kyi"
};
static const char*punkty_char[]={
(char*)"Krasnoperekopsk",
(char*)"Leninskiy",
(char*)"Nizhnegorskiy",
(char*)"Pervomaiskiy",
(char*)"Rozdolnenskiy",
(char*)"Saq-city",
(char*)"Saq",
(char*)"Simferopol city",
(char*)"Simferopol",
(char*)"Sovetskiy",
(char*)"Sudak",
(char*)"Apostolovskyi",
(char*)"Dniprodzerzhinsk",
(char*)"Dnipropetrovsk",
(char*)"Dnipropetrovskyi",
(char*)"Yuriivskyi",
(char*)"Krynychanskyi",
(char*)"Kryvorizkyi",
(char*)"",
(char*)"Magdalynivskyi",
(char*)"Marhanets",
(char*)"Mezhovyi",
(char*)"",
(char*)"Nikopolskyi",
(char*)"Novomoskovsk",
(char*)"Novomoskovskyi",
(char*)"Ordzhonikidze",
(char*)"",
(char*)"Pavlogradskyi",
(char*)"Petropavlivskyi",
(char*)"Petrykivskyi",
(char*)"Pyatyhatskyi",
(char*)"Pokrovskyi",
(char*)"Shyrochanskyi",
(char*)"Sofiivskyi",
(char*)"Solonyanskyi",
(char*)"",
(char*)"Synelnikivskyi",
(char*)"Tomakivskyi",
(char*)"Tsarychanskyi",
(char*)"Vasylkivskyi",
(char*)"",
(char*)"",
(char*)"Chornobayivskyi",
(char*)"",
(char*)"",
(char*)"Gorodyschenskyi",
(char*)"",
(char*)"",
(char*)"",
(char*)"",
(char*)"",
(char*)"KorsunShevchenkiv",
(char*)"",
(char*)"Mankivskyi",
(char*)"Monastyryshchens'",
(char*)"",
(char*)"",
(char*)"",
(char*)"",
(char*)"",
(char*)"",
(char*)"",
(char*)"",
(char*)"Bahmatskyi",
(char*)"Bobrovytskyi",
(char*)"Borznyanskyi",
(char*)"Chernigiv",
(char*)"Chernigivskyi",
(char*)"Gorodnyanskyi",
(char*)"Ichnyanskyi",
(char*)"Koryukivskyi",
(char*)"Koropskyi",
(char*)"Kozeletskyi",
(char*)"Kulykivskyi",
(char*)"Menskyi",
(char*)"",
(char*)"Nizhynskyi",
(char*)"Nosivskyi",
(char*)"NovgorodSiverskyi",
(char*)"",
(char*)"Prylutskyi",
(char*)"Ripchanskyi",
(char*)"Semenivskyi",
(char*)"Schorskyi",
(char*)"Sosnytskyi",
(char*)"Sribnyanskyi",
(char*)"Talalayivskyi",
(char*)"Varvenskyi",
(char*)"Chernivtsi",
(char*)"",
(char*)"Kelmenetskyi",
(char*)"Khotynskyi",
(char*)"Kitsmanskyi",
(char*)"Novoselytskyi",
(char*)"Putylskyi",
(char*)"Sokyryanskyi",
(char*)"Storozhynetskyi",
(char*)"Vyzhnytskyi",
(char*)"Zastavnenskyi",
(char*)"Alushta",
(char*)"Baghchasaray",
(char*)"Belogorskiy",
(char*)"Chornomorskiy",
(char*)"Dzhankoy",
(char*)"",
(char*)"Feodosiya",
(char*)"Yalta",
(char*)"",
(char*)"Kerch",
(char*)"Kirovskiy",
(char*)"Krasnohvardiyske",
(char*)"Verhnyodniprovsky",
(char*)"ZhovtiVody",
(char*)"Amvrosiivskyi",
(char*)"",
(char*)"Artemivskyi",
(char*)"Dobropillia",
(char*)"Dobropolskyi",
(char*)"Donetsk",
(char*)"Dzerzhinsk-Don",
(char*)"Gorlivka",
(char*)"",
(char*)"Yasynuvatskyi",
(char*)"Yenakiyeve",
(char*)"Khartsyzk",
(char*)"Kirovske",
(char*)"Kostyantynivka",
(char*)"Kostyantynivskyi",
(char*)"Kramatorsk",
(char*)"",
(char*)"Krasnoarmeyskyi-D",
(char*)"",
(char*)"Krasnolymanskyi",
(char*)"Makiivka",
(char*)"Mariinskyi",
(char*)"Mariupol",
(char*)"",
(char*)"",
(char*)"",
(char*)"",
(char*)"",
(char*)"",
(char*)"",
(char*)"Novoazovskyi",
(char*)"Novohrodivka",
(char*)"Oleksandrivskyi",
(char*)"",
(char*)"Selydove",
(char*)"Shahtarsk-Don",
(char*)"Shahtarskyi-Don",
(char*)"Sloviansk",
(char*)"Slovyanskyi-Don",
(char*)"Snezhnoye",
(char*)"Starobeshevskyi",
(char*)"Telmanivskyi-Don",
(char*)"Torez-Don",
(char*)"Velykonovoselivsk",
(char*)"Volnovaskyi",
(char*)"Volodarskyi",
(char*)"Vuhledar",
(char*)"Zhdanivka",
(char*)"Bogorodchanskyi",
(char*)"Dolynskyi-Ifr",
(char*)"Galytskyi",
(char*)"Gorodenkivskyi",
(char*)"Yaremcha",
(char*)"",
(char*)"Kaluskyi-Raion",
(char*)"Kolomyyskyi",
(char*)"Kosivskyi",
(char*)"Nadvirnyanskyi",
(char*)"Rogatynskyi",
(char*)"Rozhnyativskyi",
(char*)"Snyatynskyi",
(char*)"Tlumatskyi",
(char*)"Tysmenetskyi",
(char*)"Verhovynskyi",
(char*)"Balakliya",
(char*)"Barvenkove",
(char*)"Blyznyuky",
(char*)"Bohodukhiv",
(char*)"",
(char*)"",
(char*)"Chihuyiv",
(char*)"Derhachi",
(char*)"Dvuricha",
(char*)"",
(char*)"Izyum",
(char*)"Kehichivka",
(char*)"",
(char*)"Kharkivsky",
(char*)"Kkasnohrad",
(char*)"Krasnokutsk",
(char*)"",
(char*)"Kup'yansk",
(char*)"",
(char*)"Lozova",
(char*)"",
(char*)"Nova Vodolaha",
(char*)"Pechenizkyi",
(char*)"Pervomaisk",
(char*)"Sakhnovschyna",
(char*)"Shevchenkove",
(char*)"Valky",
(char*)"Velykyburluk",
(char*)"Vovchansk",
(char*)"Zachepylivka",
(char*)"Zmiyiv",
(char*)"Zolochiv",
(char*)"Beryslavskyi",
(char*)"Bilozerskyi",
(char*)"Chaplynskyi",
(char*)"Genicheskyi",
(char*)"Goloprystanskyi",
(char*)"Gornostaivskyi",
(char*)"Ivanivskyi-Her",
(char*)"Kahovskyi",
(char*)"Kalanchatskyi",
(char*)"Kherson",
(char*)"NovaKakhovka",
(char*)"Novotroitskyi",
(char*)"Novovorontsovskyi",
(char*)"Nyzhnyosirogizkyi",
(char*)"Skadovskyi",
(char*)"Tsyurupinskyi",
(char*)"Velykolepetynskyi",
(char*)"Velykooleksandriv",
(char*)"Verhnyerogachytsk",
(char*)"Vysokopilskyi",
(char*)"Bilogirskyi",
(char*)"Chemerivskyi",
(char*)"Derazhnyanskyi",
(char*)"Dunayivskyi",
(char*)"Gorodotskyi-Khm",
(char*)"Yarmolynetskyi",
(char*)"Izyaslavskyi",
(char*)"",
(char*)"KamyanetsPodilsky",
(char*)"Khmelnytskyi-Cit",
(char*)"Khmelnytskyi",
(char*)"Krasylivskyi",
(char*)"Letychivskyi",
(char*)"Novoushytskyi",
(char*)"Polonyanskyi",
(char*)"",
(char*)"Shepetivskyi",
(char*)"Slavutytskyi",
(char*)"Starokostyantyniv",
(char*)"Starosynyavskyi",
(char*)"Teofipolskyi",
(char*)"Vinkivskyi",
(char*)"Volochyskyi",
(char*)"Darnytskyi",
(char*)"Desnianskyi",
(char*)"Dniprovskyi",
(char*)"Holosiivskyi",
(char*)"Obolonskyi",
(char*)"Pecherskyi",
(char*)"Podilskyi",
(char*)"Shevchenkivskyi",
(char*)"Solomianskyi",
(char*)"Sviatoshynskyi",
(char*)"Baryshivskyi",
(char*)"BilaTserkva",
(char*)"Bilotserkovskyi",
(char*)"Boguslavskyi",
(char*)"Borodyanskyi",
(char*)"Boryspilskyi",
(char*)"",
(char*)"Brovarskyi",
(char*)"",
(char*)"Fastivskyi",
(char*)"Yagotynskyi",
(char*)"Irpin",
(char*)"Ivankivskyi",
(char*)"Kagarlytskyi",
(char*)"KyevoSvyatoshynsk",
(char*)"Makarivskyi",
(char*)"Myronivskyi",
(char*)"Obuhivskyi",
(char*)"",
(char*)"PereyaslavHmelnyt",
(char*)"Poliskyi-Kyi",
(char*)"Rokytnyanskyi",
(char*)"Skvyrskyi",
(char*)"Stavyschenskyi",
(char*)"Taraschanskyi",
(char*)"Tetiivskyi",
(char*)"Vasylkivskyi",
(char*)"Volodarskyi-Kyi",
(char*)"Vyshgorodskyi",
(char*)"Zgurivskyi",
(char*)"Bobrynetskyi",
(char*)"Dobrovelychkivsky",
(char*)"Dolynskyi-Krv",
(char*)"Gayvoronskyi",
(char*)"Golovanivskyi",
(char*)"Kirovogradskyi",
(char*)"Kompaniivskyi",
(char*)"Malovyskyi",
(char*)"Novgorodskyi",
(char*)"Novoarhangelskyi",
(char*)"Novomyrgorodskyi",
(char*)"Novoukrainskyi",
(char*)"Oleksandriyskyi",
(char*)"Oleksandrivskyi",
(char*)"Onufriivskyi",
(char*)"Petrovskyi-Krv",
(char*)"Svitlovodskyi-Krv",
(char*)"Ulyanivskyi-Krv",
(char*)"Ustynivskyi",
(char*)"Vilshanskyi",
(char*)"Znamyanskyi",
(char*)"Brodivskyi",
(char*)"Buskyi",
(char*)"Chervonohrad",
(char*)"",
(char*)"Drogobytskyi",
(char*)"Gorodotskyi-Lvi",
(char*)"Yavorivskyi",
(char*)"KamyankaBuzkyi",
(char*)"Lviv",
(char*)"Mostyskyi",
(char*)"Mykolayivskyi-Lvi",
(char*)"Peremyshlyanskyi",
(char*)"Pustomytivskyi",
(char*)"Radehivskyi",
(char*)"",
(char*)"Sambirskyi",
(char*)"Skolevskyi",
(char*)"Sokalskyi",
(char*)"Starosambirskyi",
(char*)"",
(char*)"Stryyskyi",
(char*)"Turkskyi-Lvi",
(char*)"Zhovkvovskyi",
(char*)"Zhydachivskyi",
(char*)"Zolochivskyi",
(char*)"Alchevsk",
(char*)"Antratsyt",
(char*)"Antratsytovskyi",
(char*)"Bilokurakinskyi",
(char*)"Bilovodskyi",
(char*)"Brianka",
(char*)"Kirovsk",
(char*)"Krasnodons'ka",
(char*)"Krasnodonskyi",
(char*)"",
(char*)"Kreminskyi",
(char*)"Lugansk",
(char*)"Lutuginskyi",
(char*)"Lisychansk",
(char*)"Markivskyi-Lug",
(char*)"Milovskyi",
(char*)"",
(char*)"Novoaydarskyi",
(char*)"Novopskovskyi",
(char*)"Perevalskyi",
(char*)"Popasnyanskyi",
(char*)"Rovenki",
(char*)"Rubizhne",
(char*)"Severodonetsk",
(char*)"Slovyanoserbskyi",
(char*)"Stahanov",
(char*)"StanichnoLugansky",
(char*)"Starobilskyi",
(char*)"Svatovskyi",
(char*)"Sverdlovs'ka",
(char*)"Sverdlovskyi-Lug",
(char*)"Troitskyi-Lug",
(char*)"Arbuzynskyi",
(char*)"Bashtanskyi",
(char*)"Berezanskyi",
(char*)"Berezneguvatskyi",
(char*)"Bratskyi-Myk",
(char*)"Domanivskyi",
(char*)"Yelanetskyi",
(char*)"Kazankivs'kyi",
(char*)"Kryvoozerskyi",
(char*)"Mykolayiv-Myk",
(char*)"Mykolayivskyi-Myl",
(char*)"Novobuzkyi",
(char*)"Novoodeskyi",
(char*)"Ochakivskyi",
(char*)"",
(char*)"Pervomayskyi-Myk",
(char*)"Snigurivskyi",
(char*)"Veselynovskyi",
(char*)"",
(char*)"Voznesenskyi-Myk",
(char*)"Vradiyivskyi",
(char*)"Zhovtnevyi-Myk",
(char*)"Ananyivskyi",
(char*)"Artsyzkyi",
(char*)"Baltenskyi",
(char*)"Berezivskyi-Ode",
(char*)"",
(char*)"Bilgorod Dnistrovs",
(char*)"Bilyayivskyi",
(char*)"Bolgradskyi-Ode",
(char*)"Frunzevskyi-Ode",
(char*)"Ivanivskyi-Ode",
(char*)"Izmayilskyi",
(char*)"Kiliyskyi",
(char*)"Kodymskyi",
(char*)"Kominternivskyi",
(char*)"",
(char*)"Kotovskyi-Ode",
(char*)"Krasnooknyanskyi",
(char*)"Lyubashivskyi",
(char*)"Mykolayivskyi-Ode",
(char*)"Odesa",
(char*)"Ovidiopolskyi",
(char*)"Reniyskyi",
(char*)"Rozdilnenskyi",
(char*)"Saratskyi",
(char*)"Savranskyi",
(char*)"Shyrayevskyi",
(char*)"Tarutynskyi",
(char*)"Tatarbunarskyi",
(char*)"Velykomyhaylivsky",
(char*)"Chornuskyi",
(char*)"Chutovskyi",
(char*)"Dykanskyi",
(char*)"Gadyatskyi-Pol",
(char*)"Globinskyi-Pol",
(char*)"Grebinkivskyi",
(char*)"Karlivskyi",
(char*)"Horolskyi",
(char*)"Kobelyatskyi",
(char*)"Komsomolsk-Pol",
(char*)"Kotelvskyi",
(char*)"Kozelschynskyi",
(char*)"Kremenchug-Pol",
(char*)"Kremenchutskyi",
(char*)"Lohvytskyi",
(char*)"",
(char*)"Lubenskyi",
(char*)"Mashivskyi",
(char*)"Myrgorodskyi",
(char*)"Novosanzharskyi",
(char*)"Orzhytskyi",
(char*)"Poltava",
(char*)"Poltavskyi",
(char*)"Piryatinskyi",
(char*)"Reshetylivskyi",
(char*)"Semenivskyi",
(char*)"Shyshatskyi",
(char*)"Velykobagatskyi",
(char*)"Zinkivskyi",
(char*)"Bereznyatskyi",
(char*)"Demydivskyi",
(char*)"Dubenskyi",
(char*)"Dubno",
(char*)"Dubrovytskyi",
(char*)"Goschanskyi",
(char*)"Koretskyi",
(char*)"Kostopilskyi",
(char*)"Mlynivskyi",
(char*)"Ostrozkyi-Riv",
(char*)"Radyvylivskyi",
(char*)"Rivne",
(char*)"Rivnenskyi",
(char*)"Rokytnyanskyi-Riv",
(char*)"Sarnenskyi",
(char*)"Volodymyretskyi",
(char*)"Zarichnenskyi",
(char*)"Zdolbunivskyi",
(char*)"Balaklavskiy",
(char*)"Gagarinskiy",
(char*)"Leninskiy",
(char*)"Nakhimovskiy",
(char*)"Bilopilskyi",
(char*)"Burynskyi",
(char*)"Gluhivskyi",
(char*)"Yampilskyi-Sum",
(char*)"",
(char*)"Konotopskyi",
(char*)"Krasnopilskyi",
(char*)"Krolevetskyi",
(char*)"Lebedynskyi",
(char*)"Lypovodolynskyi",
(char*)"Nedrygaylivskyi",
(char*)"",
(char*)"Ahtyrskyi-Sum",
(char*)"Putyvlskyi",
(char*)"",
(char*)"Romenskyi",
(char*)"Seredynobudskyi",
(char*)"",
(char*)"Shostskyi",
(char*)"Sumy",
(char*)"Sumskyi",
(char*)"Trostyanetskyi",
(char*)"Velykopysarivskyi",
(char*)"Berezhanskyi",
(char*)"Borschivskyi",
(char*)"Buchachskyi",
(char*)"Chortkivskyi",
(char*)"Gusyatynskyi",
(char*)"Kozovskyi",
(char*)"Kremenetskyi",
(char*)"Lanivskyi",
(char*)"Monastyryskyi",
(char*)"Pidgayskyi",
(char*)"Pidvolochinskyi",
(char*)"Shumskyi",
(char*)"Terebovlskyi",
(char*)"Ternopil",
(char*)"Ternopilskyi",
(char*)"Zalischynskyi",
(char*)"Zbarazkyi",
(char*)"Zborivskyi",
(char*)"Beregovskyi",
(char*)"Irshavskyi",
(char*)"Khustskyi",
(char*)"Mizhgirskyi",
(char*)"",
(char*)"Mukachevskyi",
(char*)"Perechynskyi",
(char*)"Rahivskyi",
(char*)"Svalyavskyi",
(char*)"Tyachivskyi",
(char*)"Uzhgorod",
(char*)"Uzhgorodskyi",
(char*)"Velykobereznyansk",
(char*)"Volovetskyi",
(char*)"Vynogradivskyi",
(char*)"Barskyi",
(char*)"Bershadskyi",
(char*)"Chechelnyskyi",
(char*)"Yampilskyi-Vin",
(char*)"Illintsivskyi",
(char*)"Kalynivskyi",
(char*)"Khmilnitskyi-Vin",
(char*)"Kozyatynskyi",
(char*)"Kryzhopilskyi",
(char*)"",
(char*)"Litynskyi",
(char*)"Lypovetskyi",
(char*)"",
(char*)"",
(char*)"MurovanoKurylovet",
(char*)"Nemyrivskyi",
(char*)"Orativskyi",
(char*)"Pischanskyi",
(char*)"Pogrebyschenskyi",
(char*)"Shargorodskyi",
(char*)"Teplytskyi",
(char*)"Tomashpilskyi",
(char*)"Trostyanetskyi",
(char*)"Tulchynskyi",
(char*)"Tyvrivskyi",
(char*)"Vinnytsya",
(char*)"Vinnytskyi",
(char*)"",
(char*)"Zhmerynskyi",
(char*)"Gorohivskyi",
(char*)"Ivanytskyi",
(char*)"KaminKashyrskyi",
(char*)"Kiveretskyi",
(char*)"",
(char*)"Kovelskyi",
(char*)"Lyubeshivskyi",
(char*)"Lyubomlskyi",
(char*)"Lokatskyi",
(char*)"Lutsk",
(char*)"Lutskyi",
(char*)"Manevytskyi",
(char*)"",
(char*)"Ratnenskyi",
(char*)"Rozhyschenskyi",
(char*)"Shatskyi",
(char*)"Starovyzhivskyi",
(char*)"Turiyskyi",
(char*)"VolodymyrVolynsky",
(char*)"Berdyansk",
(char*)"Berdyanskyi",
(char*)"Chernigivskyi-Zap",
(char*)"Enerhodar",
(char*)"Gulyaypolskyi",
(char*)"Yakymivskyi",
(char*)"KamyanskoDniprovs|KamyanskoDniprovsky",
(char*)"Kuybyshevskyi-Zap",
(char*)"Melitopol",
(char*)"Melitopolskyi",
(char*)"Myhalivskyi-Zap",
(char*)"Novomykolaivskyi",
(char*)"Orihivskyi",
(char*)"Polozkyi",
(char*)"Pryazovskyi",
(char*)"Prymorskyi-Zap",
(char*)"Rozivskyi-Zap",
(char*)"",
(char*)"Tokmakskyi",
(char*)"Vasylivskyi-Zap",
(char*)"Velykobilozerskyi",
(char*)"Veselivskyi",
(char*)"Vilnyanskyi",
(char*)"Zaporizhia",
(char*)"Zaporizkyi",
(char*)"Andrushivskyi",
(char*)"Baranivskyi",
(char*)"",
(char*)"Berdychivskyi",
(char*)"Brusylivskyi",
(char*)"Chernyahivskyi",
(char*)"Chervonoarmiyskyi",
(char*)"Chudnivskyi",
(char*)"Yemilchenskyi",
(char*)"",
(char*)"Korostenskyi",
(char*)"Korostyshivskyi",
(char*)"Lyubarskyi",
(char*)"Lugynskyi",
(char*)"Malynskyi",
(char*)"Narodytskyi",
(char*)"",
(char*)"NovogradVolynskyi",
(char*)"Olevskyi",
(char*)"Ovrutskyi",
(char*)"Popilnyanskyi",
(char*)"Radomyshlskyi",
(char*)"Romanivskyi-Zhy",
(char*)"Ruzhynskyi",
(char*)"VolodarskVolynsky",
(char*)"Zhytomyr",
(char*)"Zhytomyrskyi"
};

int itransl[]{
72,
73,
74,
75,
76,
77,
78,
79,
80,
81,
82,
83,
84,
85,
86,
87,
88,
89,
90,
91,
92,
93,
94,
95,
96,
97,
98,
99,
100,
101,
102,
103,
104,
105,
106,
107,
108,
109,
110,
111,
112,
1,
2,
3,
4,
5,
6,
7,
8,
9,
10,
11,
12,
13,
14,
15,
16,
17,
18,
19,
20,
21,
22,
23,
24,
25,
26,
27,
28,
29,
30,
31,
32,
33,
34,
35,
36,
37,
38,
39,
40,
41,
42,
43,
44,
45,
46,
47,
48,
49,
50,
51,
52,
53,
54,
55,
56,
57,
58,
59,
60,
61,
62,
63,
64,
65,
66,
67,
68,
69,
70,
71,
113,
114,
115,
116,
117,
118,
119,
120,
121,
122,
123,
124,
125,
126,
127,
128,
129,
130,
131,
132,
133,
134,
135,
136,
137,
138,
139,
140,
141,
142,
143,
144,
145,
146,
147,
148,
149,
150,
151,
152,
153,
154,
155,
156,
157,
158,
159,
160,
161,
162,
163,
164,
165,
166,
167,
168,
169,
170,
171,
172,
173,
174,
175,
176,
177,
178,
179,
180,
181,
182,
183,
184,
185,
186,
187,
188,
189,
190,
191,
192,
193,
194,
195,
196,
197,
198,
199,
200,
201,
202,
203,
204,
205,
206,
207,
208,
209,
210,
211,
212,
213,
214,
215,
216,
217,
218,
219,
220,
221,
222,
223,
224,
225,
226,
227,
228,
229,
230,
231,
232,
233,
234,
235,
236,
237,
238,
239,
240,
241,
242,
243,
244,
245,
246,
247,
248,
249,
250,
251,
252,
253,
254,
255,
256,
257,
258,
259,
260,
261,
262,
263,
264,
265,
266,
267,
268,
269,
270,
271,
272,
273,
274,
275,
276,
277,
278,
279,
280,
281,
282,
283,
284,
285,
286,
287,
288,
289,
290,
291,
292,
293,
294,
295,
296,
297,
298,
299,
300,
301,
302,
303,
304,
305,
306,
307,
308,
309,
310,
311,
312,
313,
314,
315,
316,
317,
318,
319,
320,
321,
322,
323,
324,
325,
326,
327,
328,
329,
330,
331,
332,
333,
334,
335,
336,
337,
338,
339,
340,
341,
342,
343,
344,
345,
346,
347,
348,
349,
350,
351,
352,
353,
354,
355,
356,
357,
358,
359,
360,
361,
362,
363,
364,
365,
366,
367,
368,
369,
370,
371,
372,
373,
374,
375,
376,
377,
378,
379,
380,
381,
382,
383,
384,
385,
386,
387,
388,
389,
390,
391,
392,
393,
394,
395,
396,
397,
398,
399,
400,
401,
402,
403,
404,
405,
406,
407,
408,
409,
410,
411,
412,
413,
414,
415,
416,
417,
418,
419,
420,
421,
422,
423,
424,
425,
426,
427,
428,
429,
430,
431,
432,
433,
434,
435,
436,
437,
438,
439,
440,
441,
442,
443,
444,
445,
446,
447,
448,
449,
450,
451,
452,
453,
454,
455,
456,
457,
458,
459,
460,
461,
462,
463,
464,
465,
466,
467,
468,
469,
470,
471,
472,
473,
474,
475,
476,
477,
478,
479,
480,
481,
482,
483,
484,
485,
486,
487,
488,
489,
490,
491,
492,
493,
494,
495,
496,
497,
498,
499,
500,
501,
502,
503,
504,
505,
506,
507,
508,
509,
510,
511,
512,
513,
514,
515,
516,
517,
518,
519,
520,
521,
522,
523,
524,
525,
526,
527,
528,
529,
530,
531,
532,
533,
534,
535,
536,
537,
538,
539,
540,
541,
542,
543,
544,
545,
546,
547,
548,
549,
550,
551,
552,
553,
554,
555,
556,
557,
558,
559,
560,
561,
562,
563,
564,
565,
566,
567,
568,
569,
570,
571,
572,
573,
574,
575,
576,
577,
578,
579,
580,
581,
582,
583,
584,
585,
586,
587,
588,
589,
590,
591,
592,
593,
594,
595,
596,
597,
598,
599,
600,
601,
602,
603,
604,
605,
606,
607,
608,
609,
610,
611,
612,
613,
614,
615,
616,
617,
618,
619,
620,
621,
622,
623,
624,
625,
626,
627,
628,
629
};





















































































































































































































































































































































































































































































































































































































































