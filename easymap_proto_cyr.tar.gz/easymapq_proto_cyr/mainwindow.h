#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QtGui>
#include <QMainWindow>
#include <cfloat>
#include <string>
//#include "stdlib.h"
//#include <iostream>
#include <vector>
using namespace std;
class QAction;
class QActionGroup;
class QLabel;
class QMenu;
class PolygonBrusher;

struct file_node {QString fname; QString afp; bool islink; qint64 size;};

class MainWindow : public QMainWindow
{
    Q_OBJECT

 int imagePixelSizeXd;
 int imagePixelSizeYd;
 double imageAngleSizeXcoeff;
 double imageAngleSizeYcoeff;
 double centerFrequencyd;
 double kd;
 double pyramidThresholdd;
 double pyramidDmaxd;
 int pyramidNumIterationsd;
 double mergeDMaxd;
 double mergeThresholdd;
 int filterMind;
 int filterMaxd;
 double * ellipsesXs;
 double * ellipsesYs;
 double * ellipsesAreas;
 int nEllipses;
// QFrame * fr;
// QHBoxLayout * l1;
 double scale0;
 double scale1;
 std::string * protodata;

 QStringList oblasti;
 QStringList oblasti_un;//unique
 QStringList rayony;
 QStringList punkty;
 int cur_obl; //current oblast' in scroll area
 vector <QStringList> imena_po_oblastyah;
 vector <vector <int> > ints_po_oblastyah;
// QVector <QVector <double> > dubs_po_oblastyah;
 vector <QPolygonF >  polygs;
 QVector <QVector <QPolygonF > > polygs2;
 vector <vector <PolygonBrusher * > > brushers;
 QVector <QDoubleSpinBox *> cur_spbs;
 int transl2[629];
 int im_side;
 bool im_png;
 bool im_svg;
 QTextEdit * te;
public:
 int imagePixelSizeX;
 int imagePixelSizeY;
 double imageAngleSizeX;
 double imageAngleSizeY;
 double centerFrequency;
 double k;
 double pyramidThreshold;
 double pyramidDmax;
 int pyramidNumIterations;
 double mergeDMax;
 double lambdaMax;
 double lambda;
 double mergeThreshold;
 int filterMin;
 int filterMax;
    QGraphicsView * graphicsView;
    QGraphicsScene * graphicsScene;
    QGraphicsView * graphicsView0;
public:
    QGraphicsScene * graphicsScene0;

public:
    MainWindow();
 

//protected:
    //void contextMenuEvent(QContextMenuEvent *event);

QString file_name;
QString *autofile;
public slots:
//    void oocva(QGraphicsScene * sc, QGraphicsScene * sc2, int x, int y,int epsiln, int tt, int mm,int threshld, int vaThrsh,         int sbBlockThrsh, int Ss,int suggestedW, int suggestedH);
    void run_oocva();
    void run_oocva_dlg();
    void run_oocva_cfg();
    void call_pathSim();
    void pathSim(QGraphicsScene * sc1,QGraphicsScene * sc_2, int imageW, int imgH);
    void parseEdit();
private slots:
    void chooseFile();
    int open();
    void save();
    void print();
    void about();
    void aboutQt();
    void runIIP();
    void ipsx_changed(int );
    void ipsy_changed(int );
    void iasx_changed(double);
    void iasy_changed(double);
    void centFreq_changed(double );
    void k_changed(double );
    void pyrThr_changed(double );
    void pyrDmax_changed(double );
    void pyrNumIt_changed(int );
    void mergeMax_changed(double );
    void mergeThr_changed(double );
    void fltrMin_changed(int );
    void fltrMax_changed(int );
    void lambda_changed(double );
    void runPressed();
    void putDefaults();
    void vsplitterMoved(int pos,int indx);
    void resizeV1(double scale);
    void drawEllipses(uchar * data,int x,int y,int rowpdd);
    void setECoords(int n, double * xs, double * ys, double * areas);
    void scanPath();
    void drawAttentionMap();
    void saveScanPath();
    void saveImageFiles0();
    void saveImageFiles1();
    void saveImageFiles(int which_sc);
    QRgb getHeatColor(float aval, QRgb aColor);
    void salMapWSpb_changed(int suggestdW);

    void oblast_changed(int obl);
    void imageDialog();
    void saveImageFiles();
    void getIm_sideSpin(int newside);
    void png_toggled(bool state);
    void svg_toggled(bool state);

private:
    void createActions();
    void createMenus();
    void closew();
    
    QMenu *fileMenu;
    QMenu *editMenu;
    QMenu *imageMenu;
    QMenu *helpMenu;
    QAction *chooseAct;
    QAction *openAct;
    QAction *saveAct;
    QAction *printAct;
    QAction *exitAct;
    QAction *aboutAct;
    QAction *aboutQtAct;
    QAction *pathAct;
    QAction *drawAttentionMapAct;
    QAction *pathSaveAct;
    QAction *saveImageFilesAct;
    QAction *saveImageFiles0Act;
    QAction *saveImageFiles1Act;
    QAction *runtAct;
    QAction *oocvaAct;
    QAction *oocvaConfAct;
    QAction *simAct;
    QLabel *infoLabel;
    QStringList args;
    
    QSplitter *vSplitter;

    QSpinBox * ipsx_spb;
    QSpinBox * ipsy_spb;
    QDoubleSpinBox * iasx_spb;
    QDoubleSpinBox * iasy_spb;
    QDoubleSpinBox * centFreq_spb;
    QDoubleSpinBox * k_spb;
    QDoubleSpinBox * pyrThr_spb;
    QDoubleSpinBox * pyrDmax_spb;
    QSpinBox * pyrNumIt_spb;
    QDoubleSpinBox * mergeMax_spb;
    QDoubleSpinBox * mergeThr_spb;
    QSpinBox * fltrMin_spb;
    QSpinBox * fltrMax_spb;
    QDoubleSpinBox * lambda_spb;
    //QString * filename;
    //oocva dlg controls
    QFrame * oocva_dlg;
    QSpinBox * epsilon_spb;
    QSpinBox * t_spb;
    QSpinBox * m_spb;
    QSpinBox * threshold_spb;
    QSpinBox * vaThresh_spb;
    QSpinBox * sbBlockThresh_spb;
    QSpinBox * S_spb;
    QSpinBox * salMapW_spb;
    QSpinBox * salMapH_spb;
    QGridLayout * obl_gl;
    QScrollArea * sa;
    QFrame * fr;



   // QString arg2;

};

class ThreadRunner: public QThread
{ Q_OBJECT
 
 MainWindow * wp;
 std::string * imagedata;
public: 
 ThreadRunner(std::string * bytedata, MainWindow * window_pointer);
 ~ThreadRunner(){};
protected:
 void run();
signals:
 void computed(uchar * udata, int x,int y,int rpdd);
 void sendECoords(int n, double * xs, double * ys, double * ars);
};



class PolygonBrusher: public QObject
{ Q_OBJECT
 QVector <QGraphicsPolygonItem *>  p;
 double val;
public:
 PolygonBrusher(QVector <QGraphicsPolygonItem *> polItems, double aval= -1);
 ~PolygonBrusher(){};
 double getDVal();
public slots:
 void rebrush(double newval);
 void changeItems(QVector <QGraphicsPolygonItem *>  newItems);

};



#endif
